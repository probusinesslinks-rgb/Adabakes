import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { CategoriesSection } from './components/CategoriesSection';
import { FeaturedMenu } from './components/FeaturedMenu';
import { ChefAdaSpotlight } from './components/ChefAdaSpotlight';
import { CustomCakeFunnel } from './components/CustomCakeFunnel';
import { AcademySection } from './components/AcademySection';
import { ContentHubSection } from './components/ContentHubSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { CartDrawer } from './components/CartDrawer';
import { AdminDashboard } from './components/AdminDashboard';

const MainLayout: React.FC = () => {
  const { activePage } = useApp();

  if (activePage === 'admin') {
    return (
      <main className="min-h-screen">
        <AdminDashboard />
      </main>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#FAFAFA] text-[#2C1E16]">
      <Header />

      <main className="flex-1">
        {activePage === 'home' && (
          <>
            <Hero />
            <CategoriesSection />
            <FeaturedMenu limit={6} showHeader={true} />
            <ChefAdaSpotlight />
            <TestimonialsSection />
            <ContentHubSection />
            <FaqSection />
          </>
        )}

        {activePage === 'menu' && (
          <div className="pt-4">
            <FeaturedMenu showHeader={true} />
          </div>
        )}

        {activePage === 'custom-order' && <CustomCakeFunnel />}

        {activePage === 'academy' && <AcademySection />}

        {activePage === 'content' && <ContentHubSection />}

        {activePage === 'about' && (
          <>
            <AboutSection />
            <ChefAdaSpotlight />
            <TestimonialsSection />
          </>
        )}

        {activePage === 'contact' && (
          <>
            <ContactSection />
            <FaqSection />
          </>
        )}
      </main>

      <Footer />
      <FloatingWhatsApp />
      <CartDrawer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
