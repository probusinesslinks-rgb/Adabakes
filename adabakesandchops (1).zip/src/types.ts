export type CategoryType = 'cakes' | 'small_chops' | 'pastries' | 'celebration' | 'all';

export interface Product {
  id: string;
  title: string;
  slug: string;
  category: 'cakes' | 'small_chops' | 'pastries' | 'celebration';
  price: number; // In Naira (NGN)
  piecesOrServings?: string;
  description: string;
  badge?: string;
  imageUrl: string;
  isAvailable: boolean;
  leadTimeHours?: number;
  ingredients?: string[];
  flavors?: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
  customization?: string;
}

export type OrderStatus = 'pending' | 'confirmed' | 'in_production' | 'ready' | 'delivered' | 'cancelled';

export interface Order {
  id: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  deliveryAddress: string;
  deliveryRegion: 'ikorodu' | 'mainland' | 'island' | 'pickup';
  deliveryFee: number;
  items: {
    productId: string;
    productTitle: string;
    unitPrice: number;
    quantity: number;
    customization?: string;
  }[];
  subtotal: number;
  total: number;
  paymentMethod: 'whatsapp_transfer' | 'paystack_online' | 'cash_on_pickup';
  status: OrderStatus;
  createdAt: string; // ISO string
  eventDate?: string;
  notes?: string;
}

export type BookingStatus = 'new_inquiry' | 'quote_sent' | 'deposit_paid' | 'in_baking' | 'delivered';

export interface CustomCakeBooking {
  id: string;
  bookingNumber: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  eventType: 'Wedding' | 'Birthday' | 'Anniversary' | 'Corporate' | 'Bridal Shower' | 'Other';
  eventDate: string;
  eventTime?: string;
  deliveryLocation: string; // e.g. Ikeja, Lekki, Victoria Island, Ikorodu, Surulere
  guestCount: number;
  tierCount: '1 Tier' | '2 Tiers' | '3 Tiers' | '4+ Tiers' | 'Dessert Table';
  designStyle: 'Fondant Luxury' | 'Smooth Buttercream' | 'Semi-Naked & Florals' | 'Chocolate Drip' | 'Traditional Themed';
  flavors: string[];
  smallChopsAddons?: string[];
  budgetRange: string;
  referenceImage?: string;
  specialInscription?: string;
  status: BookingStatus;
  createdAt: string;
  adminNotes?: string;
}

export interface Course {
  id: string;
  title: string;
  subtitle: string;
  price: number;
  originalPrice: number;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Professional Masterclass';
  enrolledCount: number;
  imageUrl: string;
  previewVideoUrl?: string;
  syllabus: {
    moduleTitle: string;
    lessons: string[];
  }[];
  whatYouLearn: string[];
  isAvailable: boolean;
}

export interface ContentPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  mediaType: 'youtube' | 'tiktok' | 'article';
  mediaUrl?: string;
  readTime: string;
  publishedDate: string;
  tags: string[];
  author: string;
  imageUrl: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  location: string;
  event: string;
  quote: string;
  rating: number;
  date: string;
}

export interface SiteSettings {
  announcementText: string;
  announcementEnabled: boolean;
  isWhatsAppOpen: boolean;
  operatingHours: string;
  address: string;
  phone: string;
  email: string;
  chefPhotoUrl?: string;
  deliveryFees: {
    pickup: number;
    ikorodu: number;
    mainland: number;
    island: number;
  };
  socialLinks: {
    whatsapp: string;
    facebook: string;
    tiktok: string;
    youtube: string;
    instagram: string;
  };
}
