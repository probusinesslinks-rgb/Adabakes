import { Product, Course, ContentPost, Testimonial, SiteSettings, CustomCakeBooking, Order } from '../types';
import owambePlatterImg from '../assets/images/regenerated_image_1792088775595.jpg';
import royalWeddingCakeImg from '../assets/images/royal_wedding_cake.jpg';
import pepperedGizzardImg from '../assets/images/regenerated_image_1792126506099.jpg';
import readyToGoCakesImg from '../assets/images/regenerated_image_1792129292657.png';
import bananaLoafCakeImg from '../assets/images/regenerated_image_1792129299895.jpg';
import traditionalEngagementCakeImg from '../assets/images/regenerated_image_1792139893484.jpg';
import goldenSpringRollsImg from '../assets/images/regenerated_image_1792139894130.jpg';
import meatPieImg from '../assets/images/regenerated_image_1792143087251.jpg';
import jumboSausageRollImg from '../assets/images/regenerated_image_1792143092697.jpg';
import fluffyDoughnutImg from '../assets/images/regenerated_image_1792143097033.jpg';
import crispySmallChopsPostImg from '../assets/images/regenerated_image_1792321375261.png';

export const INITIAL_PRODUCTS: Product[] = [
  // SMALL CHOPS
  {
    id: 'sc-1',
    title: 'VIP Pack of Small Chops',
    slug: 'vip-pack-of-small-chops',
    category: 'small_chops',
    price: 3500,
    piecesOrServings: 'VIP Pack (9 Pieces: 2 Samosas, 2 Spring Rolls, 1 Peppered Bite, 4 Puff-Puff)',
    description: 'Our signature party crowd-pleaser: 2 crispy Beef Samosas, 2 Flaky Spring rolls, One peppered chicken/Beef Bites, and 4 fluffy puff puff.',
    badge: 'Best Seller',
    imageUrl: owambePlatterImg,
    isAvailable: true,
    leadTimeHours: 2,
    ingredients: ['2 Crispy Beef Samosas', '2 Flaky Spring Rolls', 'Peppered Chicken/Beef Bite', '4 Fluffy Golden Puff-Puff'],
  },
  {
    id: 'sc-2',
    title: 'Royal Party Small Chops Extravaganza (100 Pieces)',
    slug: 'royal-party-small-chops-extravaganza-100-pcs',
    category: 'small_chops',
    price: 52500,
    piecesOrServings: '100 Pieces (Feeds 20-25 Guests)',
    description: 'Mega party box loaded with 30 Samosas, 30 Spring Rolls, 20 Spicy Peppered Gizzards, and 20 Jumbo Honey-Glazed Puff-Puff.',
    badge: 'Party Favorite',
    imageUrl: 'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=800&q=80',
    isAvailable: true,
    leadTimeHours: 6,
    ingredients: ['Prime Minced Beef', 'Crisp Spring Roll Sheet', 'Tender Gizzards', 'Habanero Pepper Mix', 'Nutmeg & Yeast Dough'],
  },
  {
    id: 'sc-3',
    title: 'Cocktail Crispy Beef Samosas (Pack of 20)',
    slug: 'cocktail-crispy-beef-samosas-20-pcs',
    category: 'small_chops',
    price: 12000,
    piecesOrServings: '20 Pieces',
    description: 'Ultra-thin, bubble-crisped pastry triangles filled with seasoned minced beef, fresh herbs, and mild Lagos chili.',
    imageUrl: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80',
    isAvailable: true,
    leadTimeHours: 3,
  },
  {
    id: 'sc-4',
    title: 'Golden Vegetable Spring Rolls',
    slug: 'golden-vegetable-spring-rolls',
    category: 'small_chops',
    price: 12000,
    piecesOrServings: '20 Pieces',
    description: 'Crunchy golden wrappers filled with sweet carrots, sweet corn and spring cabbage.',
    imageUrl: goldenSpringRollsImg,
    isAvailable: true,
    leadTimeHours: 3,
  },
  {
    id: 'sc-5',
    title: 'Gourmet Peppered Gizzard',
    slug: 'gourmet-peppered-gizzard',
    category: 'small_chops',
    price: 15000,
    piecesOrServings: 'Large Serving Bowl (Feeds 6-8)',
    description: 'Tender chicken gizzard tossed in an intensely flavourful pepper-onion reduction.',
    badge: 'Chef Specialty',
    imageUrl: pepperedGizzardImg,
    isAvailable: true,
    leadTimeHours: 5,
  },

  // CAKES
  {
    id: 'ck-1',
    title: 'Royal Ivory & Gold 4-Tier Wedding Cake',
    slug: 'royal-ivory-gold-4-tier-wedding-cake',
    category: 'cakes',
    price: 250000,
    piecesOrServings: '4 Tiers (Serves 150-180 Guests)',
    description: 'Exquisite architectural 4-tier wedding cake finished with pristine ivory sugar paste, handcrafted sugar rose cascading florals, and genuine edible 24K gold leaf highlights.',
    badge: 'Luxury Signature',
    imageUrl: royalWeddingCakeImg,
    isAvailable: true,
    leadTimeHours: 72,
    flavors: ['Red Velvet with Cream Cheese Buttercream', 'Rich Belgian Chocolate Fudge', 'Bourbon Vanilla Bean'],
  },
  {
    id: 'ck-2',
    title: 'Dark Belgian Chocolate Ganache Drip Celebration Cake',
    slug: 'dark-belgian-chocolate-ganache-celebration-cake',
    category: 'celebration',
    price: 45000,
    piecesOrServings: '8 Inch 3-Layer (Serves 14-18 Guests)',
    description: 'Deep, fudgy chocolate sponge layered with silken dark chocolate ganache, topped with handmade French macarons, fresh raspberries, and gold shimmer.',
    badge: 'Top Rated',
    imageUrl: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80',
    isAvailable: true,
    leadTimeHours: 24,
    flavors: ['Belgian Dark Chocolate', 'Salted Caramel Crunch'],
  },
  {
    id: 'ck-3',
    title: 'Ready To Go Cakes',
    slug: 'ready-to-go-cakes',
    category: 'celebration',
    price: 35000,
    piecesOrServings: 'Size 8 Single Layer (Serves 8-12 Guests)',
    description: 'A size 8 Single layer cake decorated with buttercream and simple design suitable for a birthday celebration, graduation, anniversary, sending personal message to your love ones.',
    badge: 'Ready To Go',
    imageUrl: readyToGoCakesImg,
    isAvailable: true,
    leadTimeHours: 4,
    flavors: ['Vanilla Buttercream', 'Velvet Red Velvet', 'Belgian Chocolate'],
  },
  {
    id: 'ck-4',
    title: 'Moist Banana Loaf Cake',
    slug: 'moist-banana-loaf-cake',
    category: 'cakes',
    price: 35000,
    piecesOrServings: 'Freshly Baked Loaf (Serves 8-12 Guests)',
    description: 'Soft Banana bread loaded with nuts, raisins and chocolate chips.',
    badge: 'Customer Favorite',
    imageUrl: bananaLoafCakeImg,
    isAvailable: true,
    leadTimeHours: 24,
  },
  {
    id: 'ck-5',
    title: 'Bespoke Traditional Nigerian Wedding Engagement Cake',
    slug: 'bespoke-traditional-nigerian-engagement-cake',
    category: 'cakes',
    price: 145000,
    piecesOrServings: '2 Tiers (Serves 70-90 Guests)',
    description: 'Sculpted and decorated with cultural regalia motif, edible coral beads, traditional wrapper drape textures, and celebratory gold crest.',
    badge: 'Cultural Masterpiece',
    imageUrl: traditionalEngagementCakeImg,
    isAvailable: true,
    leadTimeHours: 48,
  },

  // PASTRIES
  {
    id: 'ps-1',
    title: 'Savoury & Rich Meat Pie',
    slug: 'savoury-rich-meat-pie',
    category: 'pastries',
    price: 18000,
    piecesOrServings: 'Box of 10 Large Pies',
    description: 'Delicious meat pie With Flaky Crust and Rich Filling of minced meat, potato and carrot',
    badge: 'Chef Specialty',
    imageUrl: meatPieImg,
    isAvailable: true,
    leadTimeHours: 3,
  },
  {
    id: 'ps-2',
    title: 'Jumbo Sausage Roll',
    slug: 'jumbo-sausage-roll',
    category: 'pastries',
    price: 16000,
    piecesOrServings: 'Box of 10 Jumbo Rolls',
    description: 'Golden puff pastry wrapped around savory seasoned sausage meat blended with fresh thyme, black pepper, and toasted sesame seed crust.',
    imageUrl: jumboSausageRollImg,
    isAvailable: true,
    leadTimeHours: 3,
  },
  {
    id: 'ps-3',
    title: 'All-Butter French Croissants & Pain au Chocolat (Box of 6)',
    slug: 'all-butter-french-croissants-box-of-6',
    category: 'pastries',
    price: 15000,
    piecesOrServings: 'Box of 6 Assorted Pastries',
    description: 'Laminated with premium dairy butter over 48 hours for delicate honeycomb air pockets and crispy golden layers, including 3 butter croissants and 3 dark chocolate batons.',
    imageUrl: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=800&q=80',
    isAvailable: true,
    leadTimeHours: 12,
  },
  {
    id: 'ps-4',
    title: 'Fluffy Doughnut',
    slug: 'fluffy-doughnut',
    category: 'pastries',
    price: 16000,
    piecesOrServings: 'Box of 6 Fluffy Doughnuts',
    description: 'Doughnuts made to perfection with cream, jam or sardine fillings.',
    badge: 'Customer Favorite',
    imageUrl: fluffyDoughnutImg,
    isAvailable: true,
    leadTimeHours: 3,
  },
];

export const INITIAL_COURSES: Course[] = [
  {
    id: 'crs-1',
    title: 'The Commercial Small Chops Masterclass: Samosas, Spring Rolls & Puff-Puff Secrets',
    subtitle: 'From zero to commercial scale: master temperature control, paper-thin wrappers, juicy fillings, and crisp puff-puff that stays fresh for 8+ hours.',
    price: 25000,
    originalPrice: 45000,
    duration: '4.5 Hours Video + Recipe Manual',
    level: 'Beginner',
    enrolledCount: 384,
    imageUrl: 'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=800&q=80',
    previewVideoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    syllabus: [
      {
        moduleTitle: 'Module 1: The Chemistry of Crispy Dough',
        lessons: [
          'Selecting flours & oil temperature balancing',
          'Mixing dough with zero gluten rubberiness',
          'Creating paper-thin spring roll wrappers by hand',
        ],
      },
      {
        moduleTitle: 'Module 2: Flavor-Packed Samosa & Spring Roll Fillings',
        lessons: [
          'Traditional Nigerian spiced minced beef filling',
          'Shredded chicken and crisp vegetable blend',
          'Folding techniques for zero oil leakage during frying',
        ],
      },
      {
        moduleTitle: 'Module 3: The Legendary Puff-Puff Formula',
        lessons: [
          'Hydration ratios for bouncy, spherical puff-puff',
          'Preventing oily or dense interiors',
          'Catering storage, reheat guidelines & commercial pricing',
        ],
      },
      {
        moduleTitle: 'Module 4: Packaging, Pricing & Client Delivery in Lagos',
        lessons: [
          'Cost calculation per platter and profit margins',
          'Ventilated packaging to prevent soggy transit',
          'WhatsApp sales scripts for Lagos party planners',
        ],
      },
    ],
    whatYouLearn: [
      'Master translucent, crackly spring roll wrapper technique',
      'Perfect fold for triangular samosas that never burst in oil',
      'Secrets to round, oil-free puff-puff with golden chew',
      'Complete cost accounting spreadsheet and supplier contacts',
      'Downloadable printable recipe cards with exact grams',
    ],
    isAvailable: true,
  },
  {
    id: 'crs-2',
    title: 'Luxury Multi-Tier Wedding Cake Architecture & Fondant Mastery',
    subtitle: 'Design, bake, support, and stack 3-tier and 4-tier grand wedding cakes that withstand Lagos heat and transit vibrations without bulging or sinking.',
    price: 65000,
    originalPrice: 110000,
    duration: '8 Hours Comprehensive Training',
    level: 'Professional Masterclass',
    enrolledCount: 192,
    imageUrl: royalWeddingCakeImg,
    previewVideoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    syllabus: [
      {
        moduleTitle: 'Module 1: High-Density High-Flavor Cake Recipes',
        lessons: [
          'Baking structural chocolate mud & velvety sponge cakes',
          'Syrup balancing for long-lasting moisture',
          'Leveling, torting, and internal dams',
        ],
      },
      {
        moduleTitle: 'Module 2: Heat-Resistant Ganache & Sharp Edges',
        lessons: [
          'Ganache ratios for Nigerian ambient humidity (28°C-34°C)',
          'Acrylic disk method for knife-sharp 90-degree edges',
          'Troubleshooting chocolate splitting and condensation',
        ],
      },
      {
        moduleTitle: 'Module 3: Internal Doweling & Transport Engineering',
        lessons: [
          'Central locking dowel systems vs bubble straws',
          'Weight distribution formulas across tier boards',
          'Vehicle transport packaging to prevent shifting in traffic',
        ],
      },
      {
        moduleTitle: 'Module 4: Sugar Flowers & 24K Gold Leaf Application',
        lessons: [
          'Handcrafting sugar roses without expensive cutters',
          'Applying delicate edible gold foil smoothly',
          'On-site assembly and bride liaison etiquette',
        ],
      },
    ],
    whatYouLearn: [
      'Stack multi-tier cakes with zero leaning or sinking',
      'Sharp edges with heat-resistant tropical white & dark ganache',
      'Flawless paneling and fondant draping methods',
      'Transport emergency kit checklist for Lagos event halls',
    ],
    isAvailable: true,
  },
  {
    id: 'crs-3',
    title: 'Artisan Nigerian Flaky Meat Pie & Gourmet Pastry School',
    subtitle: 'Unlock the secret to bakery-grade shortcrust pastry that is rich, buttery, and melts on the tongue, filled with rich juicy meat filling.',
    price: 30000,
    originalPrice: 50000,
    duration: '3.5 Hours Video Masterclass',
    level: 'Intermediate',
    enrolledCount: 260,
    imageUrl: 'https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?auto=format&fit=crop&w=800&q=80',
    previewVideoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    syllabus: [
      {
        moduleTitle: 'Module 1: The Melt-in-Mouth Butter Pastry',
        lessons: [
          'Flour protein selection and butter cutting method',
          'Resting dough to prevent shrinkage in the oven',
        ],
      },
      {
        moduleTitle: 'Module 2: The Moist & Glossy Meat Pie Filling',
        lessons: [
          'Thickening without gummy cornstarch paste',
          'Balancing thyme, nutmeg, and aromatic stock cubes',
        ],
      },
      {
        moduleTitle: 'Module 3: Hand Pies, Fish Pies & Jumbo Sausage Rolls',
        lessons: [
          'Crimping edges without cracking',
          'Glaze chemistry for high-gloss bakery shine',
        ],
      },
    ],
    whatYouLearn: [
      'Stop making tough or soggy meat pie crusts forever',
      'Glossy, savory filling that stays moist after baking',
      'Commercial batch baking times and shelf-life extension',
    ],
    isAvailable: true,
  },
  {
    id: 'crs-4',
    title: 'Modern Buttercream Floral Piping & Sharp Edge Finishing',
    subtitle: 'Master Swiss Meringue Buttercream stability, Russian nozzles, realistic palette knife textures, and modern floral cascades.',
    price: 35000,
    originalPrice: 55000,
    duration: '4 Hours Step-by-Step Practical',
    level: 'Intermediate',
    enrolledCount: 145,
    imageUrl: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80',
    previewVideoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    syllabus: [
      {
        moduleTitle: 'Module 1: Swiss Meringue Buttercream Formulation',
        lessons: ['Egg white safety pasteurization', 'Whipping silken texture without air bubbles'],
      },
      {
        moduleTitle: 'Module 2: Knife Painting & Modern Textures',
        lessons: ['Abstract palette knife strokes', 'Ombre color blending without mud'],
      },
      {
        moduleTitle: 'Module 3: Floral Piping Masterclass',
        lessons: ['Piping realistic roses, peonies, and ranunculus', 'Flower nail handling and freezing transfers'],
      },
    ],
    whatYouLearn: [
      'Silky buttercream that does not melt at Lagos room temperature',
      'Flawless smooth cake sides with bench scrapers',
      'Expressive buttercream floral arrangement on tall cakes',
    ],
    isAvailable: true,
  },
];

export const INITIAL_POSTS: ContentPost[] = [
  {
    id: 'post-1',
    title: 'Top 5 Wedding Cake Trends Shaping Lagos Celebrations in 2026',
    slug: 'top-5-wedding-cake-trends-lagos-celebrations',
    excerpt: 'From floating illusion tiers to textured buttercream palette florals, discover the luxury cake styles dominating wedding receptions across Victoria Island and Lekki.',
    content: `When planning a luxury Nigerian wedding, the cake is not merely a dessert; it is the grand sculptural centerpiece of the entire reception. 

1. Floating Illusion Tiers: Acrylic spacer cylinders and suspended floral arches give the dramatic appearance of cake tiers hovering mid-air.
2. 24-Karat Hand-Applied Gold Leaf: Pairing raw stone textures with genuine edible gold foil.
3. Sculpted Cultural Motifs: Honoring Yoruba, Igbo, and Edo cultural attire with edible sugar lace and coral beadwork.
4. Dessert Table Installations: Complementing the grand cake with individual luxury mini cups, French macarons, and mini meat pies.
5. Tropicalized Flavor Profiles: Combining Belgian chocolate with Baileys Irish cream, salted caramel, and tropical mango curd.

At Ada Bakes & Chops, every custom wedding design begins with a personalized consultation and tasting experience to ensure your centerpiece matches your decor seamlessly.`,
    mediaType: 'article',
    readTime: '4 min read',
    publishedDate: '12 March 2026',
    tags: ['Wedding Cakes', 'Lagos Brides', 'Luxury Trends'],
    author: 'Chef Adaeze Awiri',
    imageUrl: royalWeddingCakeImg,
  },
  {
    id: 'post-2',
    title: 'The Secret Behind Small Chops That Stay Super Crispy for 6+ Hours',
    slug: 'secret-small-chops-stay-crispy-owambe',
    excerpt: 'Ever wonder why some party samosas turn soggy within 30 minutes while others retain an audible crunch all evening? Chef Adaeze reveals the culinary science.',
    content: `Nigerian party guests judge catering within the first 10 minutes, and the litmus test is almost always the small chops platter. 

The three critical factors:
1. Low-Moisture Pre-Cooking: The meat filling must be dry-sautéed without lingering steam moisture. If moisture remains inside, it steams the pastry shell from within.
2. High-Smoke Point Oil Management: Frying at exactly 175°C to 180°C seals the crust instantly without allowing oil absorption.
3. Ventilated Packaging: Never seal hot small chops in airtight polystyrene takeaway boxes without steam vents. Condensation is the enemy of crunch!

In our commercial small chops masterclass, we teach you the exact flour-to-fat ratios that give you that unforgettable shatter when you take a bite.`,
    mediaType: 'youtube',
    mediaUrl: 'https://youtube.com/@adaskitchentales?si=beLXSkF4QBani9UX',
    readTime: '3 min read',
    publishedDate: '28 February 2026',
    tags: ['Small Chops', 'Baking Tips', 'Commercial Secrets'],
    author: 'Chef Adaeze Awiri',
    imageUrl: crispySmallChopsPostImg,
  },
  {
    id: 'post-3',
    title: 'Why 100% Real Dairy Butter Beats Margarine in Tropical Lagos Heat',
    slug: 'why-real-dairy-butter-beats-margarine',
    excerpt: 'Many local bakeries default to heavy vegetable shortening and margarine. Here is why our bakery in Odogunyan Ikorodu insists on pure dairy butter.',
    content: `Margarine leaves a waxy coating on the roof of your mouth that takes minutes to dissolve. Real creamery butter, on the other hand, has a melting point that matches human body temperature precisely (37°C).

The moment a piece of our flaky meat pie or velvet sponge touches your tongue, the butter emulsifies immediately, delivering pure rich dairy aromatics.

While handling real butter in Lagos requires climate-controlled kitchens and rapid technique, the difference in mouthfeel and premium quality is night and day.`,
    mediaType: 'tiktok',
    mediaUrl: 'https://www.tiktok.com/@adas.kitchen.tales?_r=1&_t=ZS-9AKlQ76ETIr',
    readTime: '2 min read',
    publishedDate: '15 February 2026',
    tags: ['Pastry Science', 'Ingredients', 'Bakery Standards'],
    author: 'Chef Adaeze Awiri',
    imageUrl: 'https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?auto=format&fit=crop&w=800&q=80',
  },
];

export const INITIAL_TESTIMONIALS: Testimonial[] = [
  {
    id: 't-1',
    name: 'Mrs. Folashade Adeyemi',
    role: 'Bride',
    location: 'Victoria Island, Lagos',
    event: '4-Tier Wedding Cake & 200 Chops Platters',
    quote: 'Chef Adaeze exceeded every expectation! The wedding cake was the talk of Eko Hotel. Not only was it visually breathtaking, but the red velvet and Baileys chocolate were so moist people were asking for second slices.',
    rating: 5,
    date: 'February 2026',
  },
  {
    id: 't-2',
    name: 'Babatunde Olatunji',
    role: 'Managing Partner, Apex Capital',
    location: 'Ikeja GRA, Lagos',
    event: 'Annual Corporate Gala Small Chops (150 VIP Packs)',
    quote: 'The crunch on their samosas is unmatched in Lagos. Delivered right on schedule to Ikeja GRA, piping warm and elegantly boxed. Ada Bakes is our official corporate vendor now.',
    rating: 5,
    date: 'January 2026',
  },
  {
    id: 't-3',
    name: 'Chidimma Eze',
    role: 'Academy Graduate & Bakery Owner',
    location: 'Surulere, Lagos',
    event: 'Small Chops & Wedding Cake Masterclasses',
    quote: 'Taking Chef Ada’s course changed my baking business. Her lessons on heat-stable ganache and commercial pricing gave me the confidence to charge ₦150k+ per cake. She is a dedicated mentor.',
    rating: 5,
    date: 'March 2026',
  },
];

export const INITIAL_BOOKINGS: CustomCakeBooking[] = [
  {
    id: 'bk-101',
    bookingNumber: 'ABC-2026-081',
    customerName: 'Dr. Kelechi Nwosu',
    customerPhone: '+2348033221144',
    customerEmail: 'k.nwosu@gmail.com',
    eventType: 'Wedding',
    eventDate: '2026-10-24',
    eventTime: '13:00',
    deliveryLocation: 'Lekki Phase 1, Lagos',
    guestCount: 150,
    tierCount: '3 Tiers',
    designStyle: 'Fondant Luxury',
    flavors: ['Red Velvet with Cream Cheese Buttercream', 'Rich Belgian Chocolate Fudge'],
    smallChopsAddons: ['VIP Pack of Small Chops'],
    budgetRange: '₦200,000 - ₦300,000',
    specialInscription: 'Forever & Always, Kelechi & Tomi',
    status: 'in_baking',
    createdAt: '2026-10-01T09:14:00Z',
    adminNotes: 'Cake board reinforced for Lekki bridge transit. Sugar florals assembled.',
  },
  {
    id: 'bk-102',
    bookingNumber: 'ABC-2026-082',
    customerName: 'Amina Bello',
    customerPhone: '+2348122334455',
    customerEmail: 'amina.bello@yahoo.com',
    eventType: 'Birthday',
    eventDate: '2026-10-18',
    eventTime: '15:30',
    deliveryLocation: 'Magodo Phase 2, Ikeja, Lagos',
    guestCount: 30,
    tierCount: '2 Tiers',
    designStyle: 'Smooth Buttercream',
    flavors: ['Whipped Caramel Carrot Delight', 'Bourbon Vanilla Bean'],
    budgetRange: '₦70,000 - ₦100,000',
    specialInscription: 'Happy 40th Birthday Queen Amina!',
    status: 'quote_sent',
    createdAt: '2026-10-04T14:22:00Z',
  },
  {
    id: 'bk-103',
    bookingNumber: 'ABC-2026-083',
    customerName: 'Segun Adebayo',
    customerPhone: '+2348099887766',
    customerEmail: 'segun.adebayo@outlook.com',
    eventType: 'Corporate',
    eventDate: '2026-10-20',
    deliveryLocation: 'Victoria Island, Lagos',
    guestCount: 80,
    tierCount: 'Dessert Table',
    designStyle: 'Traditional Themed',
    flavors: ['Rich Belgian Chocolate Fudge'],
    smallChopsAddons: ['Royal Party Small Chops Extravaganza (100 Pieces)'],
    budgetRange: '₦150,000 - ₦250,000',
    specialInscription: 'Apex 10 Years Anniversary',
    status: 'new_inquiry',
    createdAt: '2026-10-06T08:10:00Z',
  },
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-1001',
    orderNumber: 'ABC-ORD-401',
    customerName: 'Funmilayo Davies',
    customerPhone: '+2348077665544',
    customerEmail: 'funmi.davies@gmail.com',
    deliveryAddress: '14 Admiralty Way, Lekki Phase 1',
    deliveryRegion: 'island',
    deliveryFee: 5500,
    items: [
      {
        productId: 'sc-1',
        productTitle: 'VIP Pack of Small Chops',
        unitPrice: 3500,
        quantity: 10,
      },
      {
        productId: 'ps-1',
        productTitle: 'Savoury & Rich Meat Pie',
        unitPrice: 18000,
        quantity: 1,
      },
    ],
    subtotal: 82000,
    total: 87500,
    paymentMethod: 'paystack_online',
    status: 'in_production',
    createdAt: '2026-10-06T09:30:00Z',
    eventDate: '2026-10-06',
    notes: 'Please pack sauces on the side. Call 10 mins before arrival.',
  },
  {
    id: 'ord-1002',
    orderNumber: 'ABC-ORD-402',
    customerName: 'Emeka Okafor',
    customerPhone: '+2348144556677',
    customerEmail: 'emeka.okafor@techhub.ng',
    deliveryAddress: 'Block 4, Ikorodu GRA, Lagos',
    deliveryRegion: 'ikorodu',
    deliveryFee: 1500,
    items: [
      {
        productId: 'ck-2',
        productTitle: 'Dark Belgian Chocolate Ganache Drip Celebration Cake',
        unitPrice: 45000,
        quantity: 1,
        customization: 'Write "Cheers to 35 Bro!" on cake board',
      },
    ],
    subtotal: 45000,
    total: 46500,
    paymentMethod: 'whatsapp_transfer',
    status: 'confirmed',
    createdAt: '2026-10-05T16:45:00Z',
    eventDate: '2026-10-07',
  },
];

export const INITIAL_SETTINGS: SiteSettings = {
  announcementText: '✨ Lagos Party Season: Book Custom Wedding & Birthday Cakes 14 Days in Advance for Guaranteed Slots!',
  announcementEnabled: true,
  isWhatsAppOpen: true,
  operatingHours: 'Monday - Saturday: 8:00 AM - 7:00 PM | Sunday: 12:00 PM - 5:00 PM (WAT)',
  address: '1 Agbaje Iloro Street, Odogunyan, Ikorodu, Lagos, Nigeria',
  phone: '+234 816 616 1317',
  email: 'orders@adabakesandchops.com',
  chefPhotoUrl: '/photo-1577219491135-ce391730fb2c.jpg',
  deliveryFees: {
    pickup: 0,
    ikorodu: 1500,
    mainland: 3500,
    island: 5500,
  },
  socialLinks: {
    whatsapp: 'https://wa.me/2348166161317',
    facebook: 'https://www.facebook.com/share/1DqKXZe5iz/',
    tiktok: 'https://www.tiktok.com/@adas.kitchen.tales?_r=1&_t=ZS-9AKlQ76ETIr',
    youtube: 'https://youtube.com/@adaskitchentales?si=beLXSkF4QBani9UX',
    instagram: 'https://www.instagram.com/adasbakes?stkn=dWk5b2RuYXdlcWUw',
  },
};
