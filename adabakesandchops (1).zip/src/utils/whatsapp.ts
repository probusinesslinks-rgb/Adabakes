import { CustomCakeBooking, CartItem } from '../types';

export const WHATSAPP_PHONE = '2348166161317';
export const WHATSAPP_DISPLAY_PHONE = '+234 816 616 1317';

/**
 * Format a number to Nigerian Naira string (e.g. ₦45,000)
 */
export function formatNaira(amount: number): string {
  return '₦' + amount.toLocaleString('en-NG');
}

/**
 * Format a date string to Lagos readable format
 */
export function formatLagosDate(dateString: string): string {
  try {
    const d = new Date(dateString);
    return d.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return dateString;
  }
}

/**
 * Generate a WhatsApp URL with a pre-filled custom cake booking message
 */
export function generateCustomBookingWhatsAppUrl(booking: Partial<CustomCakeBooking>): string {
  const text = `🎂 *CUSTOM CAKE & EVENT INQUIRY - ADA BAKES & CHOPS* 🎂

*Reference Code:* #${booking.bookingNumber || 'NEW'}
*Customer Name:* ${booking.customerName || 'N/A'}
*Phone Number:* ${booking.customerPhone || 'N/A'}
*Event Type:* ${booking.eventType || 'Celebration'}
*Event Date:* ${booking.eventDate || 'Pending'}
*Guest Count / Size:* ${booking.guestCount || 'N/A'} guests (${booking.tierCount || 'Bespoke'})
*Delivery Region:* ${booking.deliveryLocation || 'Lagos'}
*Preferred Style:* ${booking.designStyle || 'Custom'}
*Cake Flavors:* ${booking.flavors?.join(', ') || 'Chef Recommendation'}
${booking.smallChopsAddons?.length ? `*Small Chops Add-ons:* ${booking.smallChopsAddons.join(', ')}\n` : ''}
*Budget Range:* ${booking.budgetRange || 'Flexible'}
${booking.specialInscription ? `*Inscription/Message:* "${booking.specialInscription}"\n` : ''}
${booking.referenceImage ? `*Design Reference Provided:* Yes\n` : ''}

Hello Chef Adaeze, I would like to confirm availability and discuss finalizing my booking!`;

  return `https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(text)}`;
}

/**
 * Generate a WhatsApp URL for direct Cart Order
 */
export function generateCartOrderWhatsAppUrl(params: {
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  deliveryAddress: string;
  deliveryRegion: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  eventDate?: string;
  notes?: string;
}): string {
  const itemsText = params.items
    .map(
      (item, idx) =>
        `${idx + 1}. *${item.product.title}* x ${item.quantity} = ${formatNaira(
          item.product.price * item.quantity
        )}${item.customization ? ` _(${item.customization})_` : ''}`
    )
    .join('\n');

  const text = `🛍️ *NEW ORDER - ADA BAKES & CHOPS* 🛍️

*Order ID:* #${params.orderNumber}
*Customer:* ${params.customerName}
*Phone:* ${params.customerPhone}
*Delivery Region:* ${params.deliveryRegion.toUpperCase()}
*Delivery Address:* ${params.deliveryAddress}
${params.eventDate ? `*Preferred Delivery Date:* ${params.eventDate}\n` : ''}
*Order Items:*
${itemsText}

---------------------------------
*Subtotal:* ${formatNaira(params.subtotal)}
*Delivery Fee:* ${formatNaira(params.deliveryFee)}
*TOTAL PAYABLE:* *${formatNaira(params.total)}*
---------------------------------
${params.notes ? `*Special Notes:* ${params.notes}\n` : ''}
Hello Chef Adaeze, I have placed this order on Adabakesandchops.com and would like to confirm delivery slot & payment details.`;

  return `https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(text)}`;
}

/**
 * Quick single product WhatsApp order
 */
export function generateQuickProductWhatsAppUrl(productTitle: string, price: number): string {
  const text = `Hello Chef Adaeze! 👋 I would like to order:
*${productTitle}* (${formatNaira(price)}) from Ada Bakes and Chops.

Please let me know today's availability and delivery timeline for Lagos.`;
  return `https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(text)}`;
}

/**
 * Academy Course enrollment WhatsApp inquiry
 */
export function generateCourseEnrollmentWhatsAppUrl(courseTitle: string, price: number): string {
  const text = `Hello Chef Adaeze! 👩‍🍳 I want to enroll in the *${courseTitle}* (${formatNaira(price)}) at Ada Bakes Academy.

Please send me the enrollment steps and access link!`;
  return `https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(text)}`;
}
