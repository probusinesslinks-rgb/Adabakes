import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Award, Heart, GraduationCap, CheckCircle2, ArrowRight } from 'lucide-react';
import chefAdaPhoto from '../assets/Chief-Chef-Ada-Awiri.png';

export const ChefAdaSpotlight: React.FC = () => {
  const { navigateTo, settings } = useApp();
  const chefPhoto = settings?.chefPhotoUrl || '/photo-1577219491135-ce391730fb2c.jpg';
  const [imageSrc, setImageSrc] = useState<string>(chefPhoto);
  const [attemptIndex, setAttemptIndex] = useState(0);

  const fallbackSources = [
    '/photo-1577219491135-ce391730fb2c.jpg',
    'https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=1200&q=80',
    chefAdaPhoto,
    '/Chief-Chef-Ada-Awiri.png',
  ];

  const handleImageError = () => {
    if (attemptIndex < fallbackSources.length) {
      setImageSrc(fallbackSources[attemptIndex]);
      setAttemptIndex((prev) => prev + 1);
    }
  };

  return (
    <section className="py-20 bg-[#F7F4EE] border-y border-[#2C1E16]/10 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Visual Portrait Column (5 cols) */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Outer luxury border card */}
              <div className="relative p-3 bg-white rounded-2xl shadow-xl border border-[#2C1E16]/10">
                <div className="relative aspect-4/5 rounded-xl overflow-hidden bg-stone-200">
                  {/* Photo of Chef Adaeze Awiri */}
                  <img
                    src={imageSrc}
                    alt="Chief Chef Adaeze Awiri in white culinary uniform"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-top filter brightness-[1.02]"
                    onError={handleImageError}
                  />

                  {/* Gradient bottom scrim */}
                  <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#2C1E16]/90 via-[#2C1E16]/40 to-transparent flex flex-col justify-end p-6 text-white">
                    <span className="text-xs uppercase tracking-widest text-[#F26C22] font-bold">
                      Founder &amp; Chief Chef
                    </span>
                    <h3 className="font-serif text-2xl font-bold tracking-tight text-white">
                      Chef Adaeze Awiri
                    </h3>
                    <p className="text-xs text-stone-300">
                      Ada Bakes &amp; Chops · Odogunyan, Ikorodu
                    </p>
                  </div>
                </div>

                {/* Floating Achievement Badge */}
                <div className="absolute -bottom-5 -right-3 sm:-right-5 bg-[#2C1E16] text-white p-4 rounded-xl shadow-xl border border-[#F26C22]/30 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#F26C22] flex items-center justify-center text-white shrink-0">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-stone-300 uppercase tracking-wider font-semibold">
                      Craft Standard
                    </div>
                    <div className="text-sm font-bold text-white">
                      100% Original Ingredients
                    </div>
                  </div>
                </div>
              </div>

              {/* Decorative subtle frame offset */}
              <div className="absolute -top-3 -left-3 w-full h-full border border-[#F26C22]/30 rounded-2xl -z-10 pointer-events-none" />
            </div>
          </div>

          {/* Story & Philosophy Column (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-widest text-[#F26C22]">
                Meet The Mastermind
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C1E16] tracking-tight leading-tight">
                Crafting Edible Masterpieces With Soul &amp; Precision
              </h2>
            </div>

            <p className="text-base text-stone-700 leading-relaxed">
              "Baking is where high culinary chemistry meets unconditional passion for life’s grandest celebrations. When you order from Ada Bakes and Chops, you are never getting factory-made sponge or greasy puff-puff. Every single recipe is engineered from our kitchen studio in Odogunyan, Ikorodu using genuine creamery butter, hand-rolled delicate pastry, and balanced Nigerian seasonings."
            </p>

            <p className="text-sm text-stone-600 leading-relaxed">
              Under Chef Adaeze’s visionary direction, Ada Bakes &amp; Chops has grown from an artisanal home kitchen into one of Lagos' most respected names for luxury multi-tier wedding cakes and party catering. Through her Online Baking Academy, she has also personally mentored over 450 aspiring Nigerian and diaspora bakers to turn their passion into profitable culinary brands.
            </p>

            {/* Core Values Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="flex items-start gap-3 bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs">
                <div className="w-8 h-8 rounded-lg bg-orange-100 text-[#F26C22] flex items-center justify-center shrink-0">
                  <Heart className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-[#2C1E16]">Zero Compromise Ingredients</h4>
                  <p className="text-xs text-stone-600 mt-0.5">Real dairy cream, premium cocoa, and farm-fresh ingredients in every batch.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs">
                <div className="w-8 h-8 rounded-lg bg-orange-100 text-[#F26C22] flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-[#2C1E16]">Engineered for Lagos Climate</h4>
                  <p className="text-xs text-stone-600 mt-0.5">Specialized internal structural doweling and tropicalized heat-stable ganache.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs">
                <div className="w-8 h-8 rounded-lg bg-orange-100 text-[#F26C22] flex items-center justify-center shrink-0">
                  <GraduationCap className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-[#2C1E16]">The Baking Academy</h4>
                  <p className="text-xs text-stone-600 mt-0.5">Proven video masterclasses teaching commercial small chops and wedding cakes.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white p-4 rounded-xl border border-stone-200/80 shadow-xs">
                <div className="w-8 h-8 rounded-lg bg-orange-100 text-[#F26C22] flex items-center justify-center shrink-0">
                  <Award className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-[#2C1E16]">Lagos-Wide Delivery</h4>
                  <p className="text-xs text-stone-600 mt-0.5">Daily climate-safe dispatch across Ikorodu, Mainland, Ikeja, and Island.</p>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-4">
              <button
                onClick={() => navigateTo('custom-order')}
                className="px-6 py-3 bg-[#2C1E16] hover:bg-[#3D2B20] text-white rounded-lg text-sm font-semibold shadow-md transition-all flex items-center gap-2"
              >
                <span>Book a Custom Consultation</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => navigateTo('academy')}
                className="px-6 py-3 bg-white hover:bg-stone-100 text-[#2C1E16] border border-stone-300 rounded-lg text-sm font-semibold transition-all"
              >
                Explore Online Courses
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
