import React from 'react';
import { useApp } from '../context/AppContext';
import { ArrowRight, Cake, Sparkles, Cookie, Utensils, GraduationCap } from 'lucide-react';
import artisanPastriesImg from '../assets/images/regenerated_image_1792088765595.jpg';
import smallChopsImg from '../assets/images/regenerated_image_1792088771077.jpg';
import royalWeddingCakeImg from '../assets/images/royal_wedding_cake.jpg';

export const CategoriesSection: React.FC = () => {
  const { navigateTo } = useApp();

  const categories = [
    // 1st: Birthday & Celebration Cakes
    {
      id: 'birthday-celebration',
      title: 'Birthday & Celebration Cakes',
      subtitle: 'Modern textures, drips & florals',
      description: 'Decadent chocolate fudge, fruit, red velvet, and custom cakes. Photo/inscription toppers for milestones birthdays and celebrations',
      image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80',
      action: () => navigateTo('menu'),
      cta: 'Explore Celebration Cakes',
      icon: Cake,
      count: 'Available for Delivery',
    },
    // 2nd: Bespoke Wedding Cakes
    {
      id: 'wedding-cakes',
      title: 'Bespoke Wedding Cakes',
      subtitle: 'Multi-tier architectural sugarcraft',
      description: 'Classic Wedding Cakes. Traditional Wedding and Engagement Cakes.',
      image: royalWeddingCakeImg,
      action: () => navigateTo('custom-order'),
      cta: 'Book Wedding Cake',
      icon: Sparkles,
      count: '30+ Custom Styles',
    },
    // 3rd: Artisan Pastries & Meat Pies
    {
      id: 'artisan-pastries',
      title: 'Artisan Pastries & Meat Pies',
      subtitle: '100% pure butter shortcrust & flaky puff',
      description: 'Rich Nigerian meat pies, jumbo sausage rolls, milky doughnuts and special banana bread.',
      image: artisanPastriesImg,
      action: () => navigateTo('menu'),
      cta: 'Browse Pastry Boxes',
      icon: Cookie,
      count: 'Freshly Baked Daily',
    },
    // 4th: Lagos Gourmet Small Chops
    {
      id: 'small-chops',
      title: 'Lagos Gourmet Small Chops',
      subtitle: 'Super-crisp samosas, spring rolls & puff-puff',
      description: 'The heart of every Lagos party. Crunchy spring rolls, crispy samosa, spicy peppered gizzards, and golden puff-puff.',
      image: smallChopsImg,
      action: () => navigateTo('menu'),
      cta: 'Order Party Platters',
      icon: Utensils,
      count: 'From 20 to 500+ Packs',
    },
    // 5th: Online Baking Academy Masterclasses
    {
      id: 'baking-academy',
      title: 'Online Baking Academy',
      subtitle: 'Commercial video masterclasses',
      description: 'Learn the exact formulas to scale your baking business. Detailed recipes, video step-by-steps & WhatsApp mentorship.',
      image: 'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=800&q=80',
      action: () => navigateTo('academy'),
      cta: 'Enroll in Academy',
      icon: GraduationCap,
      count: '4 Certified Courses',
    },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#F26C22] block mb-2">
              Our Specialties
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#2C1E16] tracking-tight">
              Culinary Craftsmanship Across Every Category
            </h2>
          </div>
          <p className="text-stone-600 text-sm max-w-md">
            Whether catering an intimate birthday dinner or a 500-guest luxury wedding, every item is crafted with premium ingredients and unmatched flavor.
          </p>
        </div>

        {/* 5-Card Grid in exact requested order */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* 1st Card: Birthday & Celebration Cakes */}
          <div
            onClick={categories[0].action}
            className="group relative rounded-2xl overflow-hidden bg-stone-900 shadow-md hover:shadow-xl transition-all cursor-pointer border border-stone-200 flex flex-col justify-end min-h-[360px]"
          >
            <img
              src={categories[0].image}
              alt={categories[0].title}
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80"
              onError={(e) => {
                (e.currentTarget as HTMLElement).style.display = 'none';
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#2C1E16] via-[#2C1E16]/60 to-transparent" />
            <div className="relative p-6 text-white space-y-2">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#F26C22]">
                {categories[0].count}
              </span>
              <h3 className="font-serif text-2xl font-bold">{categories[0].title}</h3>
              <p className="text-xs text-stone-200 leading-relaxed line-clamp-3">
                {categories[0].description}
              </p>
              <div className="pt-2 flex items-center gap-1.5 text-xs font-semibold text-[#F26C22] group-hover:translate-x-1 transition-transform">
                <span>{categories[0].cta}</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* 2nd Card: Bespoke Wedding Cakes */}
          <div
            onClick={categories[1].action}
            className="group relative rounded-2xl overflow-hidden bg-stone-900 shadow-md hover:shadow-xl transition-all cursor-pointer border border-stone-200 flex flex-col justify-end min-h-[360px]"
          >
            <img
              src={categories[1].image}
              alt={categories[1].title}
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80"
              onError={(e) => {
                (e.currentTarget as HTMLElement).style.display = 'none';
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#2C1E16] via-[#2C1E16]/60 to-transparent" />
            <div className="relative p-6 text-white space-y-2">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#F26C22]">
                {categories[1].count}
              </span>
              <h3 className="font-serif text-2xl font-bold">{categories[1].title}</h3>
              <p className="text-xs text-stone-200 leading-relaxed line-clamp-3">
                {categories[1].description}
              </p>
              <div className="pt-2 flex items-center gap-1.5 text-xs font-semibold text-[#F26C22] group-hover:translate-x-1 transition-transform">
                <span>{categories[1].cta}</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* 3rd Card: Artisan Pastries & Meat Pies */}
          <div
            onClick={categories[2].action}
            className="group relative rounded-2xl overflow-hidden bg-stone-900 shadow-md hover:shadow-xl transition-all cursor-pointer border border-stone-200 flex flex-col justify-end min-h-[360px]"
          >
            <img
              src={categories[2].image}
              alt={categories[2].title}
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80"
              onError={(e) => {
                (e.currentTarget as HTMLElement).style.display = 'none';
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#2C1E16] via-[#2C1E16]/60 to-transparent" />
            <div className="relative p-6 text-white space-y-2">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#F26C22]">
                {categories[2].count}
              </span>
              <h3 className="font-serif text-2xl font-bold">{categories[2].title}</h3>
              <p className="text-xs text-stone-200 leading-relaxed line-clamp-3">
                {categories[2].description}
              </p>
              <div className="pt-2 flex items-center gap-1.5 text-xs font-semibold text-[#F26C22] group-hover:translate-x-1 transition-transform">
                <span>{categories[2].cta}</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* 4th Card: Lagos Gourmet Small Chops */}
          <div
            onClick={categories[3].action}
            className="group relative rounded-2xl overflow-hidden bg-stone-900 shadow-md hover:shadow-xl transition-all cursor-pointer border border-stone-200 flex flex-col justify-end min-h-[360px]"
          >
            <img
              src={categories[3].image}
              alt={categories[3].title}
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80"
              onError={(e) => {
                (e.currentTarget as HTMLElement).style.display = 'none';
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#2C1E16] via-[#2C1E16]/60 to-transparent" />
            <div className="relative p-6 text-white space-y-2">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#F26C22]">
                {categories[3].count}
              </span>
              <h3 className="font-serif text-2xl font-bold">{categories[3].title}</h3>
              <p className="text-xs text-stone-200 leading-relaxed line-clamp-3">
                {categories[3].description}
              </p>
              <div className="pt-2 flex items-center gap-1.5 text-xs font-semibold text-[#F26C22] group-hover:translate-x-1 transition-transform">
                <span>{categories[3].cta}</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* 5th Card: Online Baking Academy (Spans 2 cols on lg) */}
          <div
            onClick={categories[4].action}
            className="lg:col-span-2 group relative rounded-2xl overflow-hidden bg-[#2C1E16] text-white p-6 sm:p-8 shadow-md hover:shadow-xl transition-all cursor-pointer flex flex-col sm:flex-row items-center justify-between gap-6"
          >
            <div className="space-y-3 flex-1">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#F26C22]/20 text-[#F26C22] text-xs font-semibold">
                <GraduationCap className="w-4 h-4" />
                <span>Certified Baking Education</span>
              </div>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white">
                Ada Bakes Online Academy
              </h3>
              <p className="text-xs sm:text-sm text-stone-300 leading-relaxed max-w-lg">
                Step-by-step video courses on commercial small chops production, sharp-edge ganache, and structural multi-tier wedding cakes. Taught directly by Chief Chef Adaeze Awiri.
              </p>
              <div className="pt-2 flex items-center gap-2 text-xs font-bold text-[#F26C22] group-hover:translate-x-1 transition-transform">
                <span>View All 4 Masterclasses</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>

            <div className="w-full sm:w-48 h-36 rounded-xl overflow-hidden bg-stone-800 shrink-0 border border-white/10 relative">
              <img
                src={categories[4].image}
                alt="Academy preview"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                onError={(e) => {
                  (e.currentTarget as HTMLElement).style.display = 'none';
                }}
              />
              <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                <span className="w-10 h-10 rounded-full bg-white/90 text-[#2C1E16] flex items-center justify-center shadow-lg font-bold text-xs pl-0.5">
                  ▶
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
