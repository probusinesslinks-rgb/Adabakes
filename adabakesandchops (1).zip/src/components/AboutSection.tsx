import React from 'react';
import { useApp } from '../context/AppContext';
import { MapPin, Clock, Award, ShieldCheck, Heart, Sparkles, MessageCircle, ArrowRight } from 'lucide-react';
import { WHATSAPP_PHONE } from '../utils/whatsapp';

export const AboutSection: React.FC = () => {
  const { navigateTo, settings } = useApp();

  return (
    <section className="py-20 bg-[#FAFAFA] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20">
        {/* Hero Narrative */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <span className="text-xs font-bold uppercase tracking-widest text-[#F26C22] block">
              Our Heritage &amp; Kitchen Philosophy
            </span>
            <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C1E16] tracking-tight leading-tight">
              From an Artisanal Dream to Lagos' Most Trusted Celebration Bakery
            </h1>
            <p className="text-stone-700 text-sm sm:text-base leading-relaxed">
              Founded by Chief Chef Adaeze Awiri, Ada Bakes and Chops was born out of an uncompromising commitment to real pastry craftsmanship in Nigeria. In an industry where commercial bakeries frequently substitute pure creamery butter with industrial shortening and water down small chops fillings with potatoes, Chef Adaeze set a new gold standard.
            </p>
            <p className="text-stone-600 text-sm leading-relaxed">
              Based at our purpose-built culinary studio at <strong>1 Agbaje Iloro Street, Odogunyan, Ikorodu, Lagos</strong>, our team pairs traditional pastry arts with modern food science to create wedding centerpieces that remain upright and pristine despite tropical humidity.
            </p>

            <div className="pt-2 flex flex-wrap gap-4">
              <button
                onClick={() => navigateTo('custom-order')}
                className="px-6 py-3.5 bg-[#2C1E16] hover:bg-[#3D2B20] text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-md"
              >
                <span>Book Custom Wedding Cake</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <a
                href={`https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(
                  'Hello Chef Adaeze, I would like to learn more about Ada Bakes and Chops.'
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3.5 bg-white border border-stone-300 hover:bg-stone-50 text-[#2C1E16] rounded-xl text-xs font-semibold transition-colors flex items-center gap-2"
              >
                <MessageCircle className="w-4 h-4 text-[#25D366]" />
                <span>Chat with Chef Adaeze</span>
              </a>
            </div>
          </div>

          <div className="lg:col-span-5 relative">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-stone-200 bg-stone-900 aspect-4/5">
              <img
                src="https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=1000&q=80"
                alt="Culinary Studio Kitchen"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.currentTarget as HTMLElement).style.display = 'none';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#2C1E16] via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 text-white space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#F26C22]">
                  The Studio
                </span>
                <h3 className="font-serif text-xl font-bold">
                  1 Agbaje Iloro Street, Odogunyan
                </h3>
                <p className="text-xs text-stone-300">
                  Ikorodu, Lagos State, Nigeria
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* 4 Pillars of Excellence */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 pt-6">
          <div className="bg-white p-6 rounded-2xl border border-stone-200/90 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-orange-50 text-[#F26C22] flex items-center justify-center font-bold">
              <Heart className="w-5 h-5" />
            </div>
            <h4 className="font-serif text-lg font-bold text-[#2C1E16]">
              100% Real Dairy Butter
            </h4>
            <p className="text-xs text-stone-600 leading-relaxed">
              We never use artificial compound fats or hydrogenated oils. Real cream butter gives that luxurious melt on the tongue.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200/90 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-orange-50 text-[#F26C22] flex items-center justify-center font-bold">
              <Sparkles className="w-5 h-5" />
            </div>
            <h4 className="font-serif text-lg font-bold text-[#2C1E16]">
              Structural Engineering
            </h4>
            <p className="text-xs text-stone-600 leading-relaxed">
              Reinforced center food-safe doweling and temperature-balanced ganache protect your wedding cake through bumpy Lagos roads.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200/90 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-orange-50 text-[#F26C22] flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h4 className="font-serif text-lg font-bold text-[#2C1E16]">
              Party-Crisp Small Chops
            </h4>
            <p className="text-xs text-stone-600 leading-relaxed">
              Ultra-thin rolled wrappers, oil-balanced heat control, and ventilated packaging keep your samosas and spring rolls crunching for hours.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200/90 shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-xl bg-orange-50 text-[#F26C22] flex items-center justify-center font-bold">
              <Award className="w-5 h-5" />
            </div>
            <h4 className="font-serif text-lg font-bold text-[#2C1E16]">
              Online Baking Academy
            </h4>
            <p className="text-xs text-stone-600 leading-relaxed">
              Empowering next-generation African bakers with clear commercial recipes, profit accounting, and video masterclasses.
            </p>
          </div>
        </div>

        {/* Studio Location Card */}
        <div className="bg-[#2C1E16] text-white rounded-3xl p-8 sm:p-12 shadow-xl border border-[#F26C22]/20 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-4 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#F26C22]/20 text-[#F26C22] text-xs font-semibold">
              <MapPin className="w-3.5 h-3.5" />
              <span>Studio Headquarters</span>
            </div>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold">
              Visit Our Odogunyan Bakery or Request Delivery
            </h3>
            <p className="text-stone-300 text-xs sm:text-sm leading-relaxed">
              We welcome pre-scheduled wedding cake tasting sessions and self-pickups at our Odogunyan kitchen. Dispatch bikes and temperature-regulated vehicles depart daily to Ikeja, Victoria Island, Lekki, and Surulere.
            </p>
            <div className="text-xs text-stone-400 space-y-1">
              <div>📍 1 Agbaje Iloro Street, Odogunyan, Ikorodu, Lagos State</div>
              <div>🕒 {settings.operatingHours}</div>
              <div>📞 +234 816 616 1317</div>
            </div>
          </div>

          <div className="shrink-0 flex flex-col gap-3 w-full sm:w-auto">
            <a
              href={`https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(
                'Hello Chef Adaeze! I want to arrange a visit/pickup at your Odogunyan Ikorodu bakery.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-8 py-4 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-all active:scale-95"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Schedule Bakery Visit</span>
            </a>
            <button
              onClick={() => navigateTo('menu')}
              className="px-8 py-3.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-semibold transition-colors text-center"
            >
              Order Online for Delivery
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
