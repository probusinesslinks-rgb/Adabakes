import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
  variant?: 'dark' | 'light';
  subtitle?: string;
  scale?: 1 | 1.5;
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  size,
  showText = false,
  variant = 'dark',
  subtitle = 'Cakes • Pastries • Chops',
  scale = 1,
}) => {
  const isLight = variant === 'light';
  const isScaled150 = scale === 1.5;
  const svgSizeClasses = size
    ? ''
    : isScaled150
    ? 'w-[60px] h-[60px] sm:w-[66px] sm:h-[66px] md:w-[72px] md:h-[72px]'
    : 'w-10 h-10 sm:w-11 sm:h-11 md:w-12 md:h-12';
  const svgStyle = size
    ? { width: isScaled150 ? size * 1.5 : size, height: isScaled150 ? size * 1.5 : size }
    : undefined;
  const containerGap = isScaled150 ? 'gap-3.5 sm:gap-4.5' : 'gap-2.5 sm:gap-3';

  return (
    <div className={`inline-flex items-center ${containerGap} ${className}`}>
      <svg
        style={svgStyle}
        viewBox="0 0 200 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`shrink-0 transition-transform duration-300 group-hover:scale-105 ${svgSizeClasses}`}
        aria-label="Ada Bakes & Chops Logo"
      >
        <defs>
          {/* Outer golden metallic ring gradient */}
          <linearGradient id="goldRim" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F9D267" />
            <stop offset="35%" stopColor="#E5991A" />
            <stop offset="70%" stopColor="#C97508" />
            <stop offset="100%" stopColor="#FBDD88" />
          </linearGradient>

          {/* Inner golden glow */}
          <linearGradient id="innerGold" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#D98218" />
            <stop offset="50%" stopColor="#F7B839" />
            <stop offset="100%" stopColor="#EC951C" />
          </linearGradient>

          {/* Rolling pin & hat band gradient */}
          <linearGradient id="warmOrange" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#D45D08" />
            <stop offset="25%" stopColor="#F0791F" />
            <stop offset="75%" stopColor="#F8A033" />
            <stop offset="100%" stopColor="#D85E0A" />
          </linearGradient>

          {/* Radial disc background */}
          <radialGradient id="discBg" cx="50%" cy="45%" r="50%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="85%" stopColor="#FFFDF6" />
            <stop offset="100%" stopColor="#F8EED9" />
          </radialGradient>

          {/* Drop shadow for depth */}
          <filter id="softShadow" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="2" stdDeviation="2" floodColor="#301A0D" floodOpacity="0.25" />
          </filter>
        </defs>

        {/* 1. Outer Dark Chocolate Border */}
        <circle cx="100" cy="100" r="97" fill="#311B0E" />

        {/* 2. Golden Metallic Ring */}
        <circle cx="100" cy="100" r="94" fill="url(#goldRim)" />

        {/* 3. Thin Inner Chocolate Line */}
        <circle cx="100" cy="100" r="86" fill="#3D2111" />

        {/* 4. Warm Cream Center Disc */}
        <circle cx="100" cy="100" r="84" fill="url(#discBg)" />

        {/* Subtle decorative inner gold circle */}
        <circle cx="100" cy="100" r="82" stroke="url(#innerGold)" strokeWidth="1.2" fill="none" opacity="0.6" />

        {/* 5. Chef Hat at the Top */}
        <g filter="url(#softShadow)">
          {/* Puffy hat cloud lobes */}
          <path
            d="M74 52 C65 50 63 36 76 30 C82 22 100 20 108 26 C118 20 134 26 136 34 C146 38 143 50 135 54 Z"
            fill="#FFFFFF"
            stroke="#361D0F"
            strokeWidth="3.2"
            strokeLinejoin="round"
          />
          {/* Inner hat crease lines */}
          <path d="M86 38 C90 44 92 50 93 54" stroke="#E5DEC9" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M116 36 C114 42 112 49 110 54" stroke="#E5DEC9" strokeWidth="2.5" strokeLinecap="round" />

          {/* Hat base band in vibrant golden orange */}
          <path
            d="M75 52 L134 52 L131 66 C131 68 128 69 125 69 L83 69 C80 69 77 68 77 66 Z"
            fill="url(#warmOrange)"
            stroke="#361D0F"
            strokeWidth="3"
            strokeLinejoin="round"
          />
          {/* Band highlight gloss */}
          <path d="M80 56 L88 56 L85 64 L78 64 Z" fill="#FFE59E" opacity="0.8" />
        </g>

        {/* 6. Golden Splash Accents around 'Ada' */}
        {/* Left splashes */}
        <path d="M46 76 C41 78 35 77 37 72 C41 70 48 72 46 76 Z" fill="#F17E1E" stroke="#361D0F" strokeWidth="1" />
        <path d="M49 92 C42 95 38 90 41 87 C46 84 51 88 49 92 Z" fill="#F49E25" stroke="#361D0F" strokeWidth="1" />
        {/* Right splashes */}
        <path d="M154 76 C159 78 165 77 163 72 C159 70 152 72 154 76 Z" fill="#F17E1E" stroke="#361D0F" strokeWidth="1" />
        <path d="M151 92 C158 95 162 90 159 87 C154 84 149 88 151 92 Z" fill="#F49E25" stroke="#361D0F" strokeWidth="1" />

        {/* 7. "Ada" Title in Bold Chocolate Display Serif */}
        <g filter="url(#softShadow)">
          {/* Drop shadow / 3D rim */}
          <text
            x="100"
            y="99"
            textAnchor="middle"
            fill="#231208"
            fontFamily="'Playfair Display', Georgia, serif"
            fontSize="43"
            fontWeight="900"
            letterSpacing="-0.5"
          >
            Ada
          </text>
          {/* Primary front face */}
          <text
            x="100"
            y="97"
            textAnchor="middle"
            fill="#381D0E"
            fontFamily="'Playfair Display', Georgia, serif"
            fontSize="43"
            fontWeight="900"
            letterSpacing="-0.5"
          >
            Ada
          </text>
        </g>

        {/* 8. "Bakes & Chops" Typography */}
        <g filter="url(#softShadow)">
          <text
            x="100"
            y="121"
            textAnchor="middle"
            fill="#241308"
            fontFamily="'Playfair Display', Georgia, serif"
            fontSize="23.5"
            fontWeight="900"
            letterSpacing="0.2"
          >
            Bakes &amp; Chops
          </text>
          <text
            x="100"
            y="120"
            textAnchor="middle"
            fill="#3A1E0E"
            fontFamily="'Playfair Display', Georgia, serif"
            fontSize="23.5"
            fontWeight="900"
            letterSpacing="0.2"
          >
            Bakes &amp; Chops
          </text>
        </g>

        {/* 9. Baker's Rolling Pin */}
        <g filter="url(#softShadow)">
          {/* Left Handle */}
          <path
            d="M58 135 C52 135 44 133 42 136 C40 139 46 142 52 140 L58 140 Z"
            fill="#DF7017"
            stroke="#361D0F"
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
          <circle cx="43" cy="138" r="3.5" fill="#E8882E" stroke="#361D0F" strokeWidth="2" />

          {/* Right Handle */}
          <path
            d="M142 135 C148 135 156 133 158 136 C160 139 154 142 148 140 L142 140 Z"
            fill="#DF7017"
            stroke="#361D0F"
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
          <circle cx="157" cy="138" r="3.5" fill="#E8882E" stroke="#361D0F" strokeWidth="2" />

          {/* Rolling Pin Roller Body */}
          <rect
            x="58"
            y="129"
            width="84"
            height="18"
            rx="5"
            fill="url(#warmOrange)"
            stroke="#361D0F"
            strokeWidth="2.8"
          />
          {/* Highlight line on roller */}
          <path d="M64 133 L136 133" stroke="#FFE9A8" strokeWidth="2.2" strokeLinecap="round" opacity="0.8" />
          <path d="M64 142 L136 142" stroke="#B84903" strokeWidth="1.2" strokeLinecap="round" opacity="0.6" />
        </g>

        {/* 10. "CAKES • PASTRIES • CHOPS" Subtitle */}
        <text
          x="100"
          y="160"
          textAnchor="middle"
          fill="#331A0B"
          fontFamily="'Plus Jakarta Sans', system-ui, sans-serif"
          fontSize="8.6"
          fontWeight="800"
          letterSpacing="1.8"
        >
          CAKES &bull; PASTRIES &bull; CHOPS
        </text>

        {/* 11. Bottom Golden Brush Swoosh */}
        <path
          d="M74 169 C88 174 116 174 130 169 C122 172 96 172 74 169 Z"
          fill="#EBA028"
          opacity="0.9"
        />
      </svg>

      {showText && (
        <div className="flex flex-col items-start justify-center text-left select-none shrink-0 min-w-0">
          <span
            className={`font-serif font-bold tracking-tight whitespace-nowrap leading-tight ${
              isScaled150
                ? 'text-2xl sm:text-[27px] md:text-[30px] lg:text-[36px]'
                : 'text-base sm:text-lg md:text-xl lg:text-2xl'
            } ${isLight ? 'text-white' : 'text-[#2C1E16]'}`}
          >
            Ada Bakes <span className="text-[#F26C22] font-sans">&amp;</span> Chops
          </span>
          <span
            className={`uppercase tracking-wider font-semibold block whitespace-nowrap ${
              isScaled150
                ? 'text-[13px] sm:text-[14.5px] md:text-[16px] mt-1'
                : 'text-[8.5px] sm:text-[9.5px] md:text-[10.5px] mt-0.5'
            } ${isLight ? 'text-stone-300' : 'text-[#2C1E16]/75'}`}
          >
            {subtitle}
          </span>
        </div>
      )}
    </div>
  );
};
