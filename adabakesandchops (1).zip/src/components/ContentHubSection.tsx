import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ContentPost } from '../types';
import { Youtube, ExternalLink, BookOpen, Clock, Calendar, ArrowRight, X } from 'lucide-react';

export const ContentHubSection: React.FC = () => {
  const { posts, settings } = useApp();
  const [selectedPostModal, setSelectedPostModal] = useState<ContentPost | null>(null);

  return (
    <section className="py-20 bg-[#F7F4EE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="space-y-3">
            <span className="text-xs font-bold uppercase tracking-widest text-[#F26C22] block">
              Ada's Kitchen Tales · Media &amp; Recipes
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C1E16] tracking-tight">
              Baking Science, Party Guides &amp; Tutorials
            </h2>
          </div>

          {/* Social Channels Quick Links */}
          <div className="flex items-center gap-3">
            <a
              href={settings.socialLinks.youtube}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
            >
              <Youtube className="w-4 h-4" />
              <span>YouTube Channel</span>
            </a>

            <a
              href={settings.socialLinks.tiktok}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 bg-black hover:bg-stone-800 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
            >
              <span>TikTok @adas.kitchen.tales</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* 3-Column Articles & Video Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post) => (
            <article
              key={post.id}
              className="bg-white rounded-2xl overflow-hidden border border-stone-200/90 shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
            >
              {/* Media Thumbnail */}
              <div
                onClick={() => setSelectedPostModal(post)}
                className="relative aspect-16/9 bg-stone-900 cursor-pointer group overflow-hidden"
              >
                <img
                  src={post.imageUrl}
                  alt={post.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  onError={(e) => {
                    (e.currentTarget as HTMLElement).style.display = 'none';
                  }}
                />

                {/* Media Type Chip */}
                <div className="absolute top-3 left-3 bg-black/75 backdrop-blur-xs text-white text-[10px] font-semibold px-2.5 py-1 rounded-md uppercase tracking-wider flex items-center gap-1.5">
                  {post.mediaType === 'youtube' && <Youtube className="w-3 h-3 text-red-500" />}
                  <span>{post.mediaType === 'article' ? 'Editorial' : post.mediaType.toUpperCase()}</span>
                </div>

                <div className="absolute bottom-3 right-3 bg-black/70 text-white text-[10px] font-medium px-2 py-0.5 rounded flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  <span>{post.readTime}</span>
                </div>
              </div>

              {/* Content Body */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-[11px] text-stone-500">
                    <span>{post.publishedDate}</span>
                    <span aria-hidden="true">·</span>
                    <span>By {post.author}</span>
                  </div>

                  <h3
                    onClick={() => setSelectedPostModal(post)}
                    className="font-serif text-lg font-bold text-[#2C1E16] hover:text-[#F26C22] transition-colors cursor-pointer line-clamp-2 leading-snug"
                  >
                    {post.title}
                  </h3>

                  <p className="text-xs text-stone-600 line-clamp-3 leading-relaxed">
                    {post.excerpt}
                  </p>
                </div>

                <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-[11px] text-stone-500">
                    {post.tags.slice(0, 2).map((t, idx) => (
                      <span key={idx}>#{t} </span>
                    ))}
                  </div>

                  <button
                    onClick={() => setSelectedPostModal(post)}
                    className="text-xs font-bold text-[#F26C22] hover:text-[#d95914] flex items-center gap-1 group"
                  >
                    <span>Read Article</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Article Reader Modal */}
      {selectedPostModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header Image */}
            <div className="relative aspect-16/9 bg-stone-900">
              <img
                src={selectedPostModal.imageUrl}
                alt={selectedPostModal.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
              <button
                onClick={() => setSelectedPostModal(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/60 text-white hover:bg-black/80 transition-colors"
                aria-label="Close article"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="absolute bottom-4 left-6 right-6 text-white space-y-1">
                <span className="text-[10px] uppercase font-bold text-[#F26C22] tracking-wider">
                  {selectedPostModal.publishedDate} · {selectedPostModal.readTime}
                </span>
                <h2 className="font-serif text-2xl sm:text-3xl font-bold">
                  {selectedPostModal.title}
                </h2>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 sm:p-10 space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-stone-200 text-xs text-stone-500">
                <span className="font-semibold text-[#2C1E16]">Written by {selectedPostModal.author}</span>
                {selectedPostModal.mediaUrl && (
                  <a
                    href={selectedPostModal.mediaUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#F26C22] font-semibold flex items-center gap-1 hover:underline"
                  >
                    <span>Watch Video Version</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>

              <div className="prose prose-stone max-w-none text-sm text-stone-700 leading-relaxed whitespace-pre-line space-y-4">
                {selectedPostModal.content}
              </div>

              <div className="pt-6 border-t border-stone-200 flex items-center justify-between">
                <div className="flex flex-wrap gap-2 text-xs text-stone-500">
                  {selectedPostModal.tags.map((t, idx) => (
                    <span key={idx} className="bg-stone-100 px-2 py-0.5 rounded text-stone-700">
                      #{t}
                    </span>
                  ))}
                </div>

                <button
                  onClick={() => setSelectedPostModal(null)}
                  className="px-5 py-2.5 bg-[#2C1E16] text-white rounded-xl text-xs font-semibold hover:bg-[#3D2B20] transition-colors"
                >
                  Close Article
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
