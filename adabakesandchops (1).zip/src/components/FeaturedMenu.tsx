import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Product } from '../types';
import { formatNaira, generateQuickProductWhatsAppUrl } from '../utils/whatsapp';
import { ShoppingBag, MessageCircle, Clock, Check, Search, Filter } from 'lucide-react';
import royalWeddingCakeImg from '../assets/images/royal_wedding_cake.jpg';

export const FeaturedMenu: React.FC<{ limit?: number; showHeader?: boolean }> = ({
  limit,
  showHeader = true,
}) => {
  const { products, addToCart, setSelectedProduct } = useApp();
  const [activeTab, setActiveTab] = useState<'all' | 'small_chops' | 'cakes' | 'pastries'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'recommended' | 'price_low' | 'price_high'>('recommended');
  const [recentlyAddedId, setRecentlyAddedId] = useState<string | null>(null);

  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => {
        if (!p.isAvailable) return false;
        if (activeTab !== 'all') {
          if (activeTab === 'cakes') {
            return p.category === 'cakes' || p.category === 'celebration';
          }
          return p.category === activeTab;
        }
        return true;
      })
      .filter((p) => {
        if (!searchQuery.trim()) return true;
        const q = searchQuery.toLowerCase();
        return (
          p.title.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.piecesOrServings?.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        if (sortBy === 'price_low') return a.price - b.price;
        if (sortBy === 'price_high') return b.price - a.price;
        return 0;
      });
  }, [products, activeTab, searchQuery, sortBy]);

  const displayedProducts = limit ? filteredProducts.slice(0, limit) : filteredProducts;

  const handleAddToCart = (product: Product) => {
    addToCart(product, 1);
    setRecentlyAddedId(product.id);
    setTimeout(() => setRecentlyAddedId(null), 1800);
  };

  return (
    <section id="menu-section" className="py-20 bg-[#FAFAFA]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Block */}
        {showHeader && (
          <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
            <span className="text-xs font-bold uppercase tracking-widest text-[#F26C22]">
              Freshly Baked Daily in Odogunyan, Ikorodu
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C1E16] tracking-tight">
              Our Signature Bakery &amp; Chops Menu
            </h2>
            <p className="text-stone-600 text-sm leading-relaxed">
              Order individual party platters, celebration cakes, and butter pastries for direct pickup or climate-controlled delivery across Lagos.
            </p>
          </div>
        )}

        {/* Filter Bar & Controls */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-8 bg-white p-3 rounded-2xl border border-stone-200/80 shadow-xs">
          {/* Category Tabs (Segmented Buttons) */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto p-1 scrollbar-none">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'all'
                  ? 'bg-[#2C1E16] text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              All Items ({products.filter((p) => p.isAvailable).length})
            </button>
            <button
              onClick={() => setActiveTab('small_chops')}
              className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'small_chops'
                  ? 'bg-[#2C1E16] text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              Small Chops Platters
            </button>
            <button
              onClick={() => setActiveTab('cakes')}
              className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'cakes'
                  ? 'bg-[#2C1E16] text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              Signature Cakes
            </button>
            <button
              onClick={() => setActiveTab('pastries')}
              className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'pastries'
                  ? 'bg-[#2C1E16] text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              Artisan Pastries
            </button>
          </div>

          {/* Search & Sort Controls */}
          <div className="flex items-center gap-2.5 w-full md:w-auto">
            <div className="relative flex-1 md:w-56">
              <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-stone-400" />
              <input
                type="text"
                placeholder="Search menu..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-xs pl-8 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-[#F26C22] focus:bg-white"
              />
            </div>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="text-xs bg-stone-50 border border-stone-200 rounded-xl px-2.5 py-2 text-stone-700 focus:outline-none focus:border-[#F26C22]"
            >
              <option value="recommended">Featured</option>
              <option value="price_low">Price: Low to High</option>
              <option value="price_high">Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* Empty State */}
        {displayedProducts.length === 0 && (
          <div className="text-center py-16 bg-white rounded-2xl border border-stone-200">
            <p className="text-stone-500 text-sm">
              No products found matching "{searchQuery}". Try selecting another category or clear search.
            </p>
          </div>
        )}

        {/* 3-Column Product Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayedProducts.map((product) => {
            const isJustAdded = recentlyAddedId === product.id;

            return (
              <div
                key={product.id}
                className="group bg-white rounded-2xl overflow-hidden border border-stone-200/90 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
              >
                {/* Visual Top Image */}
                <div
                  onClick={() => setSelectedProduct(product)}
                  className="relative aspect-4/3 overflow-hidden bg-stone-100 cursor-pointer"
                >
                  <img
                    src={product.imageUrl}
                    alt={product.title}
                    referrerPolicy="no-referrer"
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      const img = e.currentTarget as HTMLImageElement;
                      img.onerror = null;
                      img.src = royalWeddingCakeImg;
                      img.style.display = 'block';
                    }}
                  />

                  {/* Top Badge (quiet text tag) */}
                  {product.badge && (
                    <div className="absolute top-3 left-3 bg-[#2C1E16]/90 backdrop-blur-xs text-white text-[11px] font-semibold px-2.5 py-1 rounded-md shadow-xs">
                      {product.badge}
                    </div>
                  )}

                  {product.leadTimeHours && (
                    <div className="absolute bottom-3 right-3 bg-black/60 backdrop-blur-xs text-white text-[10px] font-medium px-2 py-0.5 rounded flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{product.leadTimeHours}h notice</span>
                    </div>
                  )}
                </div>

                {/* Card Content */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-1.5">
                    {/* Quiet Metadata with typographic separators */}
                    <div className="flex items-center gap-2 text-[11px] text-stone-500">
                      <span className="capitalize">{product.category.replace('_', ' ')}</span>
                      {product.piecesOrServings && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="truncate">{product.piecesOrServings}</span>
                        </>
                      )}
                    </div>

                    <h3
                      onClick={() => setSelectedProduct(product)}
                      className="font-serif text-lg font-bold text-[#2C1E16] group-hover:text-[#F26C22] transition-colors cursor-pointer line-clamp-1"
                    >
                      {product.title}
                    </h3>

                    <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                      {product.description}
                    </p>
                  </div>

                  {/* Price & Action Row */}
                  <div className="pt-3 border-t border-stone-100 flex items-center justify-between gap-3">
                    <div>
                      <span className="text-[10px] text-stone-400 uppercase tracking-wider block font-semibold">
                        Price
                      </span>
                      <span className="font-serif text-xl font-bold text-[#2C1E16] tabular-nums">
                        {formatNaira(product.price)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {/* WhatsApp Quick Link */}
                      <a
                        href={generateQuickProductWhatsAppUrl(product.title, product.price)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2.5 rounded-xl border border-stone-200 text-stone-700 hover:text-[#25D366] hover:border-[#25D366] hover:bg-emerald-50 transition-colors"
                        title="Order this product on WhatsApp"
                        aria-label={`Order ${product.title} on WhatsApp`}
                      >
                        <MessageCircle className="w-4 h-4" />
                      </a>

                      {/* Add to Cart Button */}
                      <button
                        onClick={() => handleAddToCart(product)}
                        className={`px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs ${
                          isJustAdded
                            ? 'bg-emerald-600 text-white'
                            : 'bg-[#2C1E16] hover:bg-[#F26C22] text-white active:scale-95'
                        }`}
                      >
                        {isJustAdded ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Added</span>
                          </>
                        ) : (
                          <>
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>Add to Bag</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
