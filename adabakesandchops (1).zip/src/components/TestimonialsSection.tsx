import React from 'react';
import { useApp } from '../context/AppContext';
import { Star, Quote, Instagram, CheckCircle2, Heart } from 'lucide-react';
import royalWeddingCakeImg from '../assets/images/royal_wedding_cake.jpg';

export const TestimonialsSection: React.FC = () => {
  const { testimonials, settings } = useApp();

  const socialFeed = [
    {
      handle: '@adasbakes',
      caption: '3-tier Ivory & 24K Gold Wedding Cake dispatched to Eko Hotel ballroom. Safe travels in Lagos traffic! 🎂✨',
      image: royalWeddingCakeImg,
      likes: '1,420',
      link: settings.socialLinks.instagram,
    },
    {
      handle: '@adas.kitchen.tales',
      caption: 'Listen to this crunch! 🔊 200 crispy beef samosas fresh out of the oil for a 40th birthday in Ikeja GRA.',
      image: 'https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=600&q=80',
      likes: '3,890',
      link: settings.socialLinks.tiktok,
    },
    {
      handle: '@adasbakes',
      caption: 'Look at the flaky layers on these gourmet meat pies. 100% pure butter dough laminated to perfection.',
      image: 'https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?auto=format&fit=crop&w=600&q=80',
      likes: '840',
      link: settings.socialLinks.instagram,
    },
    {
      handle: '@adas.kitchen.tales',
      caption: 'Academy student spotlight! Chidimma just completed her first commercial 3-tier wedding cake in Surulere. So proud! 👩‍🍳',
      image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=600&q=80',
      likes: '2,110',
      link: settings.socialLinks.tiktok,
    },
  ];

  return (
    <section className="py-20 bg-white border-t border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Testimonials Block */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-[#F26C22]">
            Celebrated by Lagos Celebrants
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C1E16] tracking-tight">
            Client Words &amp; Memorable Celebrations
          </h2>
          <p className="text-stone-600 text-sm leading-relaxed">
            From grand Victoria Island wedding receptions to corporate celebrations in Ikeja GRA and thriving bakery graduates.
          </p>
        </div>

        {/* 3-Column Testimonial Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {testimonials.map((t) => (
            <div
              key={t.id}
              className="bg-[#FAFAFA] rounded-2xl p-6 sm:p-8 border border-stone-200/90 shadow-xs flex flex-col justify-between space-y-6 relative"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  {/* Star Rating */}
                  <div className="flex items-center gap-1 text-amber-500">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                  <span className="text-[11px] text-stone-400 font-medium">
                    {t.date}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-stone-700 leading-relaxed italic">
                  "{t.quote}"
                </p>
              </div>

              {/* Attribution */}
              <div className="pt-4 border-t border-stone-200 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-xs text-[#2C1E16]">{t.name}</h4>
                  <p className="text-[11px] text-stone-500">{t.role} · {t.location}</p>
                </div>
                <div className="w-8 h-8 rounded-full bg-orange-100 text-[#F26C22] flex items-center justify-center font-bold text-xs">
                  ✓
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Dynamic Social Media Grid (@adasbakes & @adas.kitchen.tales) */}
        <div className="space-y-8 pt-8 border-t border-stone-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-[#F26C22] block">
                Live From The Kitchen Studio
              </span>
              <h3 className="font-serif text-2xl font-bold text-[#2C1E16]">
                Follow @adasbakes &amp; @adas.kitchen.tales
              </h3>
            </div>

            <div className="flex items-center gap-3">
              <a
                href={settings.socialLinks.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 rounded-xl border border-stone-300 hover:border-stone-400 text-xs font-semibold text-stone-700 flex items-center gap-1.5 transition-colors"
              >
                <Instagram className="w-4 h-4 text-pink-600" />
                <span>Instagram Feed</span>
              </a>
              <a
                href={settings.socialLinks.tiktok}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 rounded-xl bg-black hover:bg-stone-800 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <span>TikTok Shorts</span>
              </a>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {socialFeed.map((item, idx) => (
              <a
                key={idx}
                href={item.link}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative aspect-square rounded-2xl overflow-hidden bg-stone-900 border border-stone-200 shadow-xs block"
              >
                <img
                  src={item.image}
                  alt={item.caption}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                  onError={(e) => {
                    (e.currentTarget as HTMLElement).style.display = 'none';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-4 flex flex-col justify-end text-white text-xs">
                  <p className="line-clamp-2 text-[11px] leading-tight text-stone-200">
                    {item.caption}
                  </p>
                  <div className="flex items-center justify-between pt-2 text-[10px] text-stone-400">
                    <span className="font-bold text-[#F26C22]">{item.handle}</span>
                    <span className="flex items-center gap-1">
                      <Heart className="w-3 h-3 text-red-400 fill-current" /> {item.likes}
                    </span>
                  </div>
                </div>
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
