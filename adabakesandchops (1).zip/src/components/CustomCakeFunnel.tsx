import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { generateCustomBookingWhatsAppUrl, formatNaira } from '../utils/whatsapp';
import {
  Cake,
  Calendar,
  MapPin,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  MessageCircle,
  Upload,
  Heart,
  Users,
} from 'lucide-react';

export const CustomCakeFunnel: React.FC = () => {
  const { addBooking, navigateTo } = useApp();
  const [currentStep, setCurrentStep] = useState(1);

  // Form State
  const [eventType, setEventType] = useState<'Wedding' | 'Birthday' | 'Anniversary' | 'Corporate' | 'Bridal Shower' | 'Other'>('Wedding');
  const [eventDate, setEventDate] = useState('');
  const [deliveryLocation, setDeliveryLocation] = useState('Lekki Phase 1 / Victoria Island');
  const [guestCount, setGuestCount] = useState(80);
  const [tierCount, setTierCount] = useState<'1 Tier' | '2 Tiers' | '3 Tiers' | '4+ Tiers' | 'Dessert Table'>('3 Tiers');
  const [designStyle, setDesignStyle] = useState<'Fondant Luxury' | 'Smooth Buttercream' | 'Semi-Naked & Florals' | 'Chocolate Drip' | 'Traditional Themed'>('Fondant Luxury');
  const [selectedFlavors, setSelectedFlavors] = useState<string[]>([
    'Red Velvet with Cream Cheese Buttercream',
    'Rich Belgian Chocolate Fudge',
  ]);
  const [selectedChopsAddons, setSelectedChopsAddons] = useState<string[]>([
    'VIP Pack of Small Chops',
  ]);
  const [budgetRange, setBudgetRange] = useState('₦150,000 - ₦250,000');
  const [specialInscription, setSpecialInscription] = useState('');
  const [referenceImageUrl, setReferenceImageUrl] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');

  // Submission State
  const [submittedBooking, setSubmittedBooking] = useState<any | null>(null);

  const flavorOptions = [
    'Red Velvet with Cream Cheese Buttercream',
    'Rich Belgian Chocolate Fudge',
    'Bourbon Vanilla Bean & Strawberry',
    'Whipped Caramel Spiced Carrot Cake',
    'Baileys Irish Cream & Coffee Mousse',
    'Coconut Velvet & Passionfruit Curd',
  ];

  const chopAddonOptions = [
    'VIP Pack of Small Chops',
    'Royal Party Small Chops Extravaganza (100 Pieces)',
    'Cocktail Beef Samosas (Pack of 20)',
    'Golden Chicken Spring Rolls (Pack of 20)',
    'Gourmet Peppered Gizzards & Snails Bowl',
  ];

  const lagosRegions = [
    'Lekki Phase 1 / Victoria Island / Ikoyi',
    'Ikeja / GRA / Maryland / Magodo',
    'Ikorodu (Town / Odogunyan / Agric)',
    'Surulere / Yaba / Ebute Metta',
    'Ajah / Sangotedo / Epe Corridor',
    'Festac / Amuwo Odofin',
    'Gbagada / Ogudu / Anthony',
  ];

  const toggleFlavor = (flavor: string) => {
    setSelectedFlavors((prev) =>
      prev.includes(flavor) ? prev.filter((f) => f !== flavor) : [...prev, flavor]
    );
  };

  const toggleChopAddon = (item: string) => {
    setSelectedChopsAddons((prev) =>
      prev.includes(item) ? prev.filter((i) => i !== item) : [...prev, item]
    );
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setReferenceImageUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim()) {
      alert('Please fill in your name and WhatsApp phone number.');
      return;
    }

    const newBooking = addBooking({
      customerName,
      customerPhone,
      customerEmail,
      eventType,
      eventDate: eventDate || new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
      deliveryLocation,
      guestCount,
      tierCount,
      designStyle,
      flavors: selectedFlavors,
      smallChopsAddons: selectedChopsAddons,
      budgetRange,
      referenceImage: referenceImageUrl,
      specialInscription,
    });

    setSubmittedBooking(newBooking);
  };

  return (
    <section className="py-16 lg:py-24 bg-[#FAFAFA] min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Step Indicator Header */}
        <div className="text-center mb-10 space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-[#F26C22]">
            Bespoke Celebration Studio
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C1E16] tracking-tight">
            Design Your Custom Luxury Cake
          </h1>
          <p className="text-stone-600 text-sm max-w-xl mx-auto">
            From multi-tier grand weddings to intimate milestone birthdays, tell us your vision and Chef Adaeze will craft your custom consultation brief.
          </p>

          {!submittedBooking && (
            <div className="flex items-center justify-center gap-2 pt-6">
              {[1, 2, 3, 4].map((step) => (
                <div key={step} className="flex items-center gap-2">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                      currentStep === step
                        ? 'bg-[#F26C22] text-white shadow-md'
                        : currentStep > step
                        ? 'bg-[#2C1E16] text-white'
                        : 'bg-stone-200 text-stone-600'
                    }`}
                  >
                    {step}
                  </div>
                  {step < 4 && (
                    <div
                      className={`w-8 sm:w-16 h-1 rounded-full ${
                        currentStep > step ? 'bg-[#2C1E16]' : 'bg-stone-200'
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Completion View */}
        {submittedBooking ? (
          <div className="bg-white rounded-3xl p-8 sm:p-12 shadow-xl border border-stone-200 text-center space-y-6 animate-in fade-in duration-300">
            <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-12 h-12" />
            </div>

            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-widest text-[#F26C22]">
                Inquiry Saved to Admin CRM
              </span>
              <h2 className="font-serif text-3xl font-bold text-[#2C1E16]">
                Consultation Brief #{submittedBooking.bookingNumber} Created!
              </h2>
              <p className="text-sm text-stone-600 max-w-lg mx-auto leading-relaxed">
                Thank you, {submittedBooking.customerName}! Your custom cake specification has been logged in our kitchen database. To discuss directly with Chef Adaeze and finalize your date, send your brief to WhatsApp with 1 click:
              </p>
            </div>

            {/* Brief Snapshot Card */}
            <div className="bg-[#F7F4EE] rounded-2xl p-6 text-left max-w-lg mx-auto border border-stone-200/80 text-xs text-stone-700 space-y-2">
              <div className="flex justify-between border-b border-stone-200 pb-2 font-semibold">
                <span>Event:</span>
                <span className="text-[#2C1E16]">{submittedBooking.eventType} ({submittedBooking.tierCount})</span>
              </div>
              <div className="flex justify-between border-b border-stone-200 pb-2">
                <span>Target Date:</span>
                <span className="font-semibold text-[#2C1E16]">{submittedBooking.eventDate}</span>
              </div>
              <div className="flex justify-between border-b border-stone-200 pb-2">
                <span>Delivery:</span>
                <span className="font-semibold text-[#2C1E16]">{submittedBooking.deliveryLocation}</span>
              </div>
              <div className="flex justify-between border-b border-stone-200 pb-2">
                <span>Style:</span>
                <span className="font-semibold text-[#2C1E16]">{submittedBooking.designStyle}</span>
              </div>
              <div>
                <span className="text-stone-500 block mb-1">Selected Flavors:</span>
                <span className="font-semibold text-[#2C1E16]">{submittedBooking.flavors.join(', ')}</span>
              </div>
            </div>

            {/* Primary WhatsApp Dispatch Action */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <a
                href={generateCustomBookingWhatsAppUrl(submittedBooking)}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-8 py-4 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-xl text-sm font-bold flex items-center justify-center gap-2.5 shadow-lg active:scale-95 transition-all"
              >
                <MessageCircle className="w-5 h-5" />
                <span>Send Brief to Chef Adaeze on WhatsApp</span>
              </a>

              <button
                onClick={() => {
                  setSubmittedBooking(null);
                  setCurrentStep(1);
                  navigateTo('menu');
                }}
                className="w-full sm:w-auto px-6 py-4 bg-white border border-stone-300 hover:bg-stone-50 text-[#2C1E16] rounded-xl text-sm font-semibold transition-colors"
              >
                Browse Shop Menu
              </button>
            </div>
          </div>
        ) : (
          /* Multi-Step Form Container */
          <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-xl border border-stone-200/90">
            {/* STEP 1: Event Type & Scale */}
            {currentStep === 1 && (
              <div className="space-y-8 animate-in fade-in duration-200">
                <div className="border-b border-stone-100 pb-4">
                  <h3 className="font-serif text-2xl font-bold text-[#2C1E16]">
                    Step 1: Event Type &amp; Guest Size
                  </h3>
                  <p className="text-xs text-stone-500 mt-1">
                    Select the celebration format and size so we can calibrate portioning.
                  </p>
                </div>

                {/* Event Type Grid */}
                <div className="space-y-3">
                  <label className="text-xs font-bold uppercase tracking-wider text-stone-700 block">
                    What are you celebrating?
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {[
                      'Wedding',
                      'Birthday',
                      'Anniversary',
                      'Corporate',
                      'Bridal Shower',
                      'Other',
                    ].map((type) => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setEventType(type as any)}
                        className={`p-4 rounded-xl border text-left transition-all ${
                          eventType === type
                            ? 'border-[#F26C22] bg-orange-50/50 text-[#2C1E16] font-bold shadow-xs'
                            : 'border-stone-200 hover:border-stone-300 text-stone-700'
                        }`}
                      >
                        <Cake className={`w-5 h-5 mb-2 ${eventType === type ? 'text-[#F26C22]' : 'text-stone-400'}`} />
                        <span className="text-xs block">{type}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Cake Tier Scale */}
                <div className="space-y-3">
                  <label className="text-xs font-bold uppercase tracking-wider text-stone-700 block">
                    Preferred Tier Structure:
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {['1 Tier', '2 Tiers', '3 Tiers', '4+ Tiers', 'Dessert Table'].map((t) => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => setTierCount(t as any)}
                        className={`py-3 px-2 rounded-xl border text-xs text-center transition-all ${
                          tierCount === t
                            ? 'border-[#2C1E16] bg-[#2C1E16] text-white font-bold'
                            : 'border-stone-200 hover:border-stone-300 text-stone-700'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Guest Count Slider */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-stone-700 uppercase tracking-wider">
                      Estimated Guests to Feed:
                    </span>
                    <span className="font-serif text-lg font-bold text-[#F26C22] tabular-nums">
                      {guestCount} Guests
                    </span>
                  </div>
                  <input
                    type="range"
                    min="15"
                    max="500"
                    step="5"
                    value={guestCount}
                    onChange={(e) => setGuestCount(Number(e.target.value))}
                    className="w-full accent-[#F26C22] cursor-pointer"
                  />
                  <div className="flex justify-between text-[11px] text-stone-400">
                    <span>15 (Intimate)</span>
                    <span>100 (Classic)</span>
                    <span>250+ (Owambe Banquet)</span>
                  </div>
                </div>

                <div className="flex justify-end pt-4">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(2)}
                    className="px-8 py-3.5 bg-[#2C1E16] hover:bg-[#3D2B20] text-white rounded-xl text-xs font-semibold flex items-center gap-2 transition-transform active:scale-95"
                  >
                    <span>Next: Date &amp; Lagos Location</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 2: Date & Lagos Delivery Location */}
            {currentStep === 2 && (
              <div className="space-y-8 animate-in fade-in duration-200">
                <div className="border-b border-stone-100 pb-4">
                  <h3 className="font-serif text-2xl font-bold text-[#2C1E16]">
                    Step 2: Date &amp; Lagos Delivery Location
                  </h3>
                  <p className="text-xs text-stone-500 mt-1">
                    Custom wedding cakes require at least 7-14 days advance booking for handcrafted florals.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-stone-700 block">
                      Target Event Date *
                    </label>
                    <div className="relative">
                      <Calendar className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
                      <input
                        type="date"
                        value={eventDate}
                        onChange={(e) => setEventDate(e.target.value)}
                        className="w-full text-xs pl-9 pr-3 py-2.5 border border-stone-300 rounded-xl focus:outline-none focus:border-[#F26C22]"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-stone-700 block">
                      Budget Expectations
                    </label>
                    <select
                      value={budgetRange}
                      onChange={(e) => setBudgetRange(e.target.value)}
                      className="w-full text-xs px-3 py-2.5 border border-stone-300 rounded-xl focus:outline-none focus:border-[#F26C22]"
                    >
                      <option value="₦50,000 - ₦80,000">₦50,000 - ₦80,000 (1 Tier / Standard)</option>
                      <option value="₦80,000 - ₦150,000">₦80,000 - ₦150,000 (2 Tiers)</option>
                      <option value="₦150,000 - ₦250,000">₦150,000 - ₦250,000 (3 Tiers / Florals)</option>
                      <option value="₦250,000 - ₦500,000+">₦250,000 - ₦500,000+ (Luxury Grand Tiers)</option>
                    </select>
                  </div>
                </div>

                {/* Delivery Region Selection */}
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-stone-700 block">
                    Delivery Destination in Lagos:
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {lagosRegions.map((region) => (
                      <button
                        key={region}
                        type="button"
                        onClick={() => setDeliveryLocation(region)}
                        className={`p-3 rounded-xl border text-left text-xs transition-all flex items-center gap-2.5 ${
                          deliveryLocation === region
                            ? 'border-[#2C1E16] bg-[#2C1E16] text-white font-semibold'
                            : 'border-stone-200 hover:border-stone-300 text-stone-700'
                        }`}
                      >
                        <MapPin className={`w-3.5 h-3.5 shrink-0 ${deliveryLocation === region ? 'text-[#F26C22]' : 'text-stone-400'}`} />
                        <span className="truncate">{region}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(1)}
                    className="px-6 py-3.5 border border-stone-300 hover:bg-stone-50 text-stone-700 rounded-xl text-xs font-semibold flex items-center gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCurrentStep(3)}
                    className="px-8 py-3.5 bg-[#2C1E16] hover:bg-[#3D2B20] text-white rounded-xl text-xs font-semibold flex items-center gap-2 transition-transform active:scale-95"
                  >
                    <span>Next: Flavors &amp; Design Style</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: Flavors, Style & Small Chops Add-on */}
            {currentStep === 3 && (
              <div className="space-y-8 animate-in fade-in duration-200">
                <div className="border-b border-stone-100 pb-4">
                  <h3 className="font-serif text-2xl font-bold text-[#2C1E16]">
                    Step 3: Design Style, Flavors &amp; Chops Add-ons
                  </h3>
                  <p className="text-xs text-stone-500 mt-1">
                    Select your preferred cake icing medium and combine with our signature small chops catering.
                  </p>
                </div>

                {/* Design Styles */}
                <div className="space-y-3">
                  <label className="text-xs font-bold uppercase tracking-wider text-stone-700 block">
                    Preferred Exterior Finish:
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    {[
                      'Fondant Luxury',
                      'Smooth Buttercream',
                      'Semi-Naked & Florals',
                      'Chocolate Drip',
                      'Traditional Themed',
                    ].map((style) => (
                      <button
                        key={style}
                        type="button"
                        onClick={() => setDesignStyle(style as any)}
                        className={`p-3 rounded-xl border text-left text-xs transition-all ${
                          designStyle === style
                            ? 'border-[#F26C22] bg-orange-50 text-[#2C1E16] font-bold shadow-xs'
                            : 'border-stone-200 text-stone-700 hover:border-stone-300'
                        }`}
                      >
                        <Sparkles className={`w-4 h-4 mb-1.5 ${designStyle === style ? 'text-[#F26C22]' : 'text-stone-400'}`} />
                        <span>{style}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Cake Flavors Multiple Selection */}
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-stone-700 block">
                    Select Sponge Flavors (Choose 1 to 3):
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {flavorOptions.map((flavor) => {
                      const selected = selectedFlavors.includes(flavor);
                      return (
                        <button
                          key={flavor}
                          type="button"
                          onClick={() => toggleFlavor(flavor)}
                          className={`p-2.5 rounded-xl border text-left text-xs transition-all flex items-center justify-between ${
                            selected
                              ? 'border-[#2C1E16] bg-[#2C1E16] text-white font-medium'
                              : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                          }`}
                        >
                          <span className="truncate pr-2">{flavor}</span>
                          {selected && <CheckCircle2 className="w-3.5 h-3.5 text-[#F26C22] shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Small Chops Catering Add-ons */}
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-stone-700 block">
                    Add Lagos Party Small Chops Platters?
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {chopAddonOptions.map((addon) => {
                      const selected = selectedChopsAddons.includes(addon);
                      return (
                        <button
                          key={addon}
                          type="button"
                          onClick={() => toggleChopAddon(addon)}
                          className={`p-2.5 rounded-xl border text-left text-xs transition-all flex items-center justify-between ${
                            selected
                              ? 'border-[#F26C22] bg-orange-50 text-[#2C1E16] font-semibold'
                              : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                          }`}
                        >
                          <span className="truncate pr-2">{addon}</span>
                          {selected ? (
                            <span className="text-[#F26C22] font-bold text-xs">✓ Included</span>
                          ) : (
                            <span className="text-stone-400 text-xs">+ Add</span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Reference Image or Special Inscription */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-stone-700 block">
                      Custom Inscription on Board / Cake
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Happy 50th Birthday Mummy!"
                      value={specialInscription}
                      onChange={(e) => setSpecialInscription(e.target.value)}
                      className="w-full text-xs border border-stone-300 rounded-xl px-3 py-2.5 focus:outline-none focus:border-[#F26C22]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-stone-700 block">
                      Upload Inspiration Photo (Optional)
                    </label>
                    <label className="flex items-center gap-2 p-2.5 border border-dashed border-stone-300 hover:border-[#F26C22] rounded-xl cursor-pointer text-xs text-stone-600 bg-stone-50">
                      <Upload className="w-4 h-4 text-[#F26C22] shrink-0" />
                      <span className="truncate">
                        {referenceImageUrl ? 'Photo Attached ✓' : 'Click to select picture'}
                      </span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(2)}
                    className="px-6 py-3.5 border border-stone-300 hover:bg-stone-50 text-stone-700 rounded-xl text-xs font-semibold flex items-center gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCurrentStep(4)}
                    className="px-8 py-3.5 bg-[#2C1E16] hover:bg-[#3D2B20] text-white rounded-xl text-xs font-semibold flex items-center gap-2 transition-transform active:scale-95"
                  >
                    <span>Next: Finalize &amp; WhatsApp Brief</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 4: Contact & Direct Submission */}
            {currentStep === 4 && (
              <form onSubmit={handleSubmit} className="space-y-8 animate-in fade-in duration-200">
                <div className="border-b border-stone-100 pb-4">
                  <h3 className="font-serif text-2xl font-bold text-[#2C1E16]">
                    Step 4: Your Contact Details
                  </h3>
                  <p className="text-xs text-stone-500 mt-1">
                    Enter your contact information so Chef Adaeze can review your brief and send your detailed quote.
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-stone-700 block">
                        Your Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Bolanle Alabi"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        className="w-full text-xs border border-stone-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-[#F26C22]"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-stone-700 block">
                        WhatsApp Phone Number *
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="e.g. 0816 616 1317"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        className="w-full text-xs border border-stone-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-[#F26C22]"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-stone-700 block">
                      Email Address (Optional)
                    </label>
                    <input
                      type="email"
                      placeholder="e.g. bolanle@gmail.com"
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      className="w-full text-xs border border-stone-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-[#F26C22]"
                    />
                  </div>
                </div>

                {/* Summary Box */}
                <div className="p-4 bg-orange-50/60 rounded-2xl border border-orange-200/80 text-xs text-stone-700 space-y-1">
                  <div className="font-bold text-[#2C1E16] flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-[#F26C22]" />
                    <span>Inquiry Overview</span>
                  </div>
                  <p>
                    {eventType} Cake ({tierCount}, {designStyle}) for {guestCount} guests in {deliveryLocation}.
                  </p>
                  <p className="text-[11px] text-stone-500">
                    Flavors: {selectedFlavors.join(', ')} · Budget: {budgetRange}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-4">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(3)}
                    className="px-6 py-3.5 border border-stone-300 hover:bg-stone-50 text-stone-700 rounded-xl text-xs font-semibold flex items-center gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back</span>
                  </button>

                  <button
                    type="submit"
                    className="px-8 py-4 bg-[#F26C22] hover:bg-[#d95914] text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg active:scale-95 transition-all"
                  >
                    <span>Generate Consultation Brief</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </section>
  );
};
