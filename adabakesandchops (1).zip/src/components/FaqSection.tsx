import React, { useState } from 'react';
import { ChevronDown, HelpCircle, MessageCircle } from 'lucide-react';
import { WHATSAPP_PHONE } from '../utils/whatsapp';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'How far in advance should I order custom wedding and celebration cakes?',
      a: 'For multi-tier bespoke wedding cakes, we recommend booking at least 2 to 4 weeks in advance, especially during Lagos peak festive and wedding seasons. For signature celebration cakes and small chops platters, we can accommodate orders placed 24 to 48 hours in advance.',
    },
    {
      q: 'How do your cakes withstand Lagos heat and traffic without melting or tilting?',
      a: 'We use specialized internal structural doweling engineered for tropical transit, paired with our heat-resistant Belgian chocolate ganache undercoat. This ensures your cake stays knife-sharp and level through Lagos traffic conditions from Ikorodu all the way to Lekki and Victoria Island.',
    },
    {
      q: 'What are your delivery areas and rates across Lagos State?',
      a: 'We deliver daily across Lagos! Pickup at our Odogunyan, Ikorodu studio is completely free. Local Ikorodu dispatch is ₦1,500, Lagos Mainland (Ikeja, Surulere, Maryland, Yaba) is ₦3,500, and Lagos Island / Lekki / VI is ₦5,500. All deliveries are handled by trained, climate-aware drivers.',
    },
    {
      q: 'Can I request a wedding cake tasting before placing a deposit?',
      a: 'Yes, absolutely! We offer pre-scheduled bridal tasting boxes containing 4 of our signature sponge flavors with accompanying buttercream samples. You can collect from our Odogunyan studio or have it dispatched to your Lagos doorstep.',
    },
    {
      q: 'How do the Online Baking Academy courses work?',
      a: 'Upon enrollment, you receive instant lifetime access to the video lessons, downloadable printable recipe guides with exact gram weights, costing templates, and access to Chef Adaeze’s private student WhatsApp community for direct troubleshooting.',
    },
    {
      q: 'What payment methods do you accept?',
      a: 'We accept instant debit card payments via Paystack, direct Nigerian bank transfers, and verified WhatsApp order confirmations with invoice references.',
    },
  ];

  return (
    <section className="py-20 bg-[#FAFAFA]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14 space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-[#F26C22]">
            Got Questions?
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#2C1E16] tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="text-stone-600 text-sm">
            Everything you need to know about placing custom orders, Lagos delivery, and academy courses.
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="bg-white rounded-2xl border border-stone-200/90 overflow-hidden transition-all duration-200"
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 focus:outline-none"
                >
                  <span className="font-serif text-base font-bold text-[#2C1E16]">
                    {faq.q}
                  </span>
                  <div
                    className={`w-7 h-7 rounded-full bg-stone-100 flex items-center justify-center shrink-0 text-[#2C1E16] transition-transform duration-200 ${
                      isOpen ? 'rotate-180 bg-[#F26C22] text-white' : ''
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-stone-600 leading-relaxed border-t border-stone-100 animate-in fade-in duration-200">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-12 p-6 rounded-2xl bg-[#F7F4EE] border border-stone-200 text-center flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <h4 className="font-serif text-base font-bold text-[#2C1E16]">
              Still have a specific question?
            </h4>
            <p className="text-xs text-stone-500">
              Chef Adaeze and our kitchen team are happy to assist via WhatsApp.
            </p>
          </div>
          <a
            href={`https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(
              'Hello Chef Adaeze, I have a question not listed in the FAQ.'
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs shrink-0"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Ask on WhatsApp</span>
          </a>
        </div>
      </div>
    </section>
  );
};
