import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MapPin, Phone, Mail, Clock, MessageCircle, Send, CheckCircle2 } from 'lucide-react';
import { WHATSAPP_PHONE } from '../utils/whatsapp';

export const ContactSection: React.FC = () => {
  const { settings } = useApp();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('Custom Cake Consultation');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !message.trim()) {
      alert('Please complete the required fields.');
      return;
    }

    const text = `📬 *NEW WEBSITE INQUIRY - ADA BAKES & CHOPS*

*Name:* ${name}
*Phone:* ${phone}
*Email:* ${email || 'N/A'}
*Subject:* ${subject}
*Message:*
${message}`;

    window.open(`https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(text)}`, '_blank');
    setSubmitted(true);
  };

  return (
    <section className="py-20 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-[#F26C22]">
            Get In Touch
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C1E16] tracking-tight">
            We Would Love to Sweeten Your Next Event
          </h1>
          <p className="text-stone-600 text-sm leading-relaxed">
            Reach out for custom wedding cake consultations, party small chops catering reservations, or baking academy enrollment support.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Contact Details & Odogunyan Map card (5 cols) */}
          <div className="lg:col-span-5 space-y-8">
            <div className="bg-[#F7F4EE] rounded-3xl p-8 border border-stone-200/90 shadow-xs space-y-6">
              <h3 className="font-serif text-2xl font-bold text-[#2C1E16]">
                Studio &amp; Office
              </h3>

              <div className="space-y-4 text-xs sm:text-sm text-stone-700">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-orange-100 text-[#F26C22] flex items-center justify-center shrink-0 mt-0.5">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="block text-[#2C1E16]">Physical Address:</strong>
                    <span>1 Agbaje Iloro Street, Odogunyan, Ikorodu, Lagos State, Nigeria</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-orange-100 text-[#F26C22] flex items-center justify-center shrink-0 mt-0.5">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="block text-[#2C1E16]">Direct Line &amp; WhatsApp:</strong>
                    <a
                      href={`https://wa.me/${WHATSAPP_PHONE}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#F26C22] font-semibold hover:underline"
                    >
                      +234 816 616 1317
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-orange-100 text-[#F26C22] flex items-center justify-center shrink-0 mt-0.5">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="block text-[#2C1E16]">Email Inquiries:</strong>
                    <span>orders@adabakesandchops.com</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-orange-100 text-[#F26C22] flex items-center justify-center shrink-0 mt-0.5">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="block text-[#2C1E16]">Operating Hours:</strong>
                    <span>{settings.operatingHours}</span>
                  </div>
                </div>
              </div>

              {/* Quick WhatsApp Button */}
              <div className="pt-2">
                <a
                  href={`https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(
                    'Hello Chef Adaeze! I would like to make an inquiry with Ada Bakes and Chops.'
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3.5 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Start WhatsApp Chat Now</span>
                </a>
              </div>
            </div>

            {/* Map Visual Card */}
            <div className="bg-stone-900 rounded-3xl p-6 text-white space-y-3 border border-stone-800 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#F26C22] tracking-wider">
                    Lagos Coverage Map
                  </span>
                  <h4 className="font-serif text-lg font-bold">
                    Odogunyan Studio Hub
                  </h4>
                </div>
                <span className="text-xs bg-white/10 px-2.5 py-1 rounded-md text-emerald-400 font-semibold">
                  Active Dispatch
                </span>
              </div>
              <p className="text-xs text-stone-300 leading-relaxed">
                Centrally positioned in Ikorodu with direct logistics arterial connections to Lagos Mainland (Maryland, Ikeja GRA, Surulere) and Island (Victoria Island, Lekki, Ikoyi).
              </p>
            </div>
          </div>

          {/* Inquiry Form (7 cols) */}
          <div className="lg:col-span-7 bg-[#FAFAFA] rounded-3xl p-8 sm:p-10 border border-stone-200/90 shadow-xs">
            {submitted ? (
              <div className="py-12 text-center space-y-4">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-[#2C1E16]">
                  Message Dispatched!
                </h3>
                <p className="text-sm text-stone-600 max-w-md mx-auto">
                  Thank you, {name}! Your message has been routed to Chef Adaeze. If you opened WhatsApp, your inquiry is ready to send in one tap.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-4 px-6 py-2.5 bg-[#2C1E16] text-white rounded-xl text-xs font-semibold"
                >
                  Send Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <h3 className="font-serif text-2xl font-bold text-[#2C1E16]">
                    Send a Direct Message
                  </h3>
                  <p className="text-xs text-stone-500 mt-1">
                    Fill out the form below to connect directly with our kitchen management.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-stone-700 block">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Adeola Johnson"
                      className="w-full text-xs bg-white border border-stone-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-[#F26C22]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-stone-700 block">
                      WhatsApp Phone *
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="e.g. 0816 616 1317"
                      className="w-full text-xs bg-white border border-stone-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-[#F26C22]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-stone-700 block">
                      Email Address
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. adeola@gmail.com"
                      className="w-full text-xs bg-white border border-stone-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-[#F26C22]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-stone-700 block">
                      Subject *
                    </label>
                    <select
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      className="w-full text-xs bg-white border border-stone-300 rounded-xl px-3 py-2.5 focus:outline-none focus:border-[#F26C22]"
                    >
                      <option value="Custom Cake Consultation">Custom Cake Consultation</option>
                      <option value="Party Small Chops Catering">Party Small Chops Catering</option>
                      <option value="Online Academy Enrollment">Online Academy Enrollment</option>
                      <option value="Corporate Event Vendor Inquiry">Corporate Event Vendor Inquiry</option>
                      <option value="Bakery Studio Visit">Bakery Studio Visit</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-stone-700 block">
                    Your Message / Event Date &amp; Specifications *
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Tell us about your celebration, date, location in Lagos, and any special design ideas..."
                    className="w-full text-xs bg-white border border-stone-300 rounded-xl p-3.5 focus:outline-none focus:border-[#F26C22]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-[#2C1E16] hover:bg-[#3D2B20] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-all active:scale-98"
                >
                  <Send className="w-4 h-4 text-[#F26C22]" />
                  <span>Send Message &amp; Open WhatsApp</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
