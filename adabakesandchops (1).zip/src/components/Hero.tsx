import React from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, MessageCircle, ArrowRight, ShieldCheck, Star } from 'lucide-react';
import { WHATSAPP_PHONE } from '../utils/whatsapp';
import royalWeddingCakeImg from '../assets/images/royal_wedding_cake.jpg';

export const Hero: React.FC = () => {
  const { navigateTo } = useApp();

  return (
    <section className="relative bg-[#FAFAFA] pt-8 pb-16 lg:pt-16 lg:pb-24 overflow-hidden">
      {/* Background soft ambient accents */}
      <div className="absolute top-0 right-0 -mr-24 -mt-24 w-96 h-96 rounded-full bg-[#F26C22]/5 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -ml-24 -mb-24 w-96 h-96 rounded-full bg-[#2C1E16]/5 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Text & CTA Content (7 cols) */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            {/* Quiet trust kicker */}
            <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#F26C22] bg-[#F26C22]/10 px-3.5 py-1.5 rounded-full mx-auto lg:mx-0">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Odogunyan Studio, Ikorodu · Delivering Across Lagos</span>
            </div>

            {/* Primary Headline with balance */}
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-extrabold text-[#2C1E16] tracking-tight leading-[1.15] max-w-2xl mx-auto lg:mx-0">
              Lagos' Premier Destination for{' '}
              <span className="text-[#F26C22] italic font-serif">Luxury Cakes</span> &amp; Culinary Excellence
            </h1>

            {/* Sub-headline */}
            <p className="text-base sm:text-lg text-stone-600 leading-relaxed max-w-xl mx-auto lg:mx-0">
              Bespoke multi-tiered wedding centerpieces, shatteringly crisp party small chops, and elite masterclasses by Chief Chef Adaeze Awiri. Handcrafted with 100% pure creamery butter.
            </p>

            {/* Primary Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-2">
              <button
                onClick={() => navigateTo('menu')}
                className="w-full sm:w-auto px-7 py-3.5 bg-[#2C1E16] hover:bg-[#3D2B20] text-white rounded-xl text-sm font-semibold shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center gap-2 group active:scale-95"
              >
                <span>Order Now / View Menu</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => navigateTo('custom-order')}
                className="w-full sm:w-auto px-6 py-3.5 bg-[#F26C22] hover:bg-[#d95914] text-white rounded-xl text-sm font-semibold shadow-md hover:shadow-lg transition-all duration-200 flex items-center justify-center gap-2 active:scale-95"
              >
                <span>Design Custom Cake</span>
              </button>

              <a
                href={`https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(
                  'Hello Chef Adaeze! I would like to inquire about ordering cakes and small chops.'
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-5 py-3.5 bg-white hover:bg-stone-50 text-[#2C1E16] border border-stone-300 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4 text-[#25D366]" />
                <span>WhatsApp</span>
              </a>
            </div>

            {/* Trust Markers Bar */}
            <div className="pt-6 border-t border-stone-200 grid grid-cols-3 gap-4 max-w-lg mx-auto lg:mx-0 text-left">
              <div>
                <div className="font-serif text-2xl font-bold text-[#2C1E16] tabular-nums">
                  2,500+
                </div>
                <div className="text-xs text-stone-500 font-medium mt-0.5">
                  Cakes Delivered
                </div>
              </div>

              <div>
                <div className="font-serif text-2xl font-bold text-[#2C1E16] tabular-nums">
                  100%
                </div>
                <div className="text-xs text-stone-500 font-medium mt-0.5">
                  Pure Dairy Butter
                </div>
              </div>

              <div>
                <div className="font-serif text-2xl font-bold text-[#2C1E16] tabular-nums">
                  450+
                </div>
                <div className="text-xs text-stone-500 font-medium mt-0.5">
                  Academy Bakers
                </div>
              </div>
            </div>
          </div>

          {/* Right Visual Showcase (5 cols) */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Primary Showcase Card */}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-stone-200/80 bg-stone-900 group">
                <div className="aspect-4/3 w-full relative">
                  <img
                    src={royalWeddingCakeImg}
                    alt="Luxury multi-tiered wedding cake by Ada Bakes and Chops"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                </div>

                {/* Scrim Overlay Details */}
                <div className="absolute bottom-0 inset-x-0 p-5 text-white flex items-end justify-between">
                  <div>
                    <div className="flex items-center gap-1 text-amber-400 text-xs mb-1">
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span className="text-stone-300 ml-1 text-[11px]">(5.0 Lagos Weddings)</span>
                    </div>
                    <h3 className="font-serif text-lg font-bold">
                      Royal Ivory &amp; 24K Gold Tier
                    </h3>
                    <p className="text-xs text-stone-300">
                      Signature handcrafted wedding collection
                    </p>
                  </div>

                  <button
                    onClick={() => navigateTo('custom-order')}
                    className="px-3 py-1.5 bg-[#F26C22] text-white rounded-lg text-xs font-semibold hover:bg-[#d95914] transition-colors shrink-0"
                  >
                    Inquire
                  </button>
                </div>
              </div>

              {/* Floating Small Chops Card Overlay */}
              <div className="absolute -bottom-6 -left-6 sm:-left-8 bg-white p-3.5 rounded-xl shadow-xl border border-stone-200 flex items-center gap-3.5 max-w-xs animate-in slide-in-from-bottom-2 duration-300">
                <div className="w-14 h-14 rounded-lg overflow-hidden bg-stone-100 shrink-0">
                  <img
                    src="https://images.unsplash.com/photo-1541544741938-0af808871cc0?auto=format&fit=crop&w=400&q=80"
                    alt="Lagos Party Small Chops"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.currentTarget as HTMLElement).style.display = 'none';
                    }}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <span className="text-[10px] uppercase font-bold text-[#F26C22] tracking-wider block">
                    Party Platter
                  </span>
                  <h4 className="text-xs font-bold text-[#2C1E16] truncate">
                    Lagos VIP Small Chops
                  </h4>
                  <p className="text-[11px] text-stone-500 font-medium">
                    Crispy Samosa &amp; Puff-Puff
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
