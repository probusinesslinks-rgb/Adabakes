import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Course } from '../types';
import { formatNaira, generateCourseEnrollmentWhatsAppUrl, WHATSAPP_PHONE } from '../utils/whatsapp';
import {
  GraduationCap,
  Clock,
  CheckCircle2,
  Play,
  Users,
  BookOpen,
  Award,
  ArrowRight,
  MessageCircle,
  X,
  CreditCard,
  ShieldCheck,
} from 'lucide-react';

export const AcademySection: React.FC = () => {
  const { courses, enrollInCourse, settings } = useApp();
  const [activeCourseModal, setActiveCourseModal] = useState<Course | null>(null);
  const [enrolledSuccessCourse, setEnrolledSuccessCourse] = useState<Course | null>(null);
  const [studentName, setStudentName] = useState('');
  const [studentPhone, setStudentPhone] = useState('');
  const [studentEmail, setStudentEmail] = useState('');
  const [isProcessingEnrollment, setIsProcessingEnrollment] = useState(false);

  const handleOpenCourse = (course: Course) => {
    setActiveCourseModal(course);
  };

  const handleEnrollCheckout = (course: Course) => {
    if (!studentName.trim() || !studentPhone.trim()) {
      alert('Please provide your name and WhatsApp phone number to enroll.');
      return;
    }

    setIsProcessingEnrollment(true);

    setTimeout(() => {
      enrollInCourse(course.id);
      setIsProcessingEnrollment(false);
      setActiveCourseModal(null);
      setEnrolledSuccessCourse(course);
    }, 1200);
  };

  return (
    <section className="py-20 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-100 text-[#F26C22] text-xs font-bold uppercase tracking-wider">
            <GraduationCap className="w-4 h-4" />
            <span>Ada Bakes Culinary Institute</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C1E16] tracking-tight">
            Learn Elite Baking &amp; Commercial Pastry Secrets
          </h1>
          <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
            Gain immediate access to Chief Chef Adaeze Awiri's battle-tested formulas. Stop guessing dough ratios, soggy crusts, and collapsing cake tiers.
          </p>
        </div>

        {/* Benefits Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-16 max-w-4xl mx-auto">
          <div className="p-4 bg-[#F7F4EE] rounded-2xl border border-stone-200/80 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#2C1E16] text-white flex items-center justify-center shrink-0">
              <Play className="w-5 h-5 text-[#F26C22]" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-[#2C1E16]">Lifetime Video Access</h4>
              <p className="text-[11px] text-stone-500">HD step-by-step camera angles</p>
            </div>
          </div>

          <div className="p-4 bg-[#F7F4EE] rounded-2xl border border-stone-200/80 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#2C1E16] text-white flex items-center justify-center shrink-0">
              <BookOpen className="w-5 h-5 text-[#F26C22]" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-[#2C1E16]">Printable Recipe Cards</h4>
              <p className="text-[11px] text-stone-500">Exact gram weights &amp; costing</p>
            </div>
          </div>

          <div className="p-4 bg-[#F7F4EE] rounded-2xl border border-stone-200/80 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#2C1E16] text-white flex items-center justify-center shrink-0">
              <Award className="w-5 h-5 text-[#F26C22]" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-[#2C1E16]">Chef Mentorship</h4>
              <p className="text-[11px] text-stone-500">Direct WhatsApp Q&amp;A support</p>
            </div>
          </div>
        </div>

        {/* Course Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {courses.map((course) => (
            <div
              key={course.id}
              className="bg-white rounded-3xl overflow-hidden border border-stone-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              {/* Media Thumbnail */}
              <div
                onClick={() => handleOpenCourse(course)}
                className="relative aspect-16/9 bg-stone-900 cursor-pointer group overflow-hidden"
              >
                <img
                  src={course.imageUrl}
                  alt={course.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                  onError={(e) => {
                    (e.currentTarget as HTMLElement).style.display = 'none';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                {/* Level badge */}
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-xs text-[#2C1E16] text-[11px] font-bold px-3 py-1 rounded-md">
                  {course.level}
                </div>

                {/* Duration */}
                <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-xs text-white text-[11px] font-medium px-2.5 py-1 rounded-md flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{course.duration}</span>
                </div>

                {/* Play Button Overlay */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-[#F26C22] text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  </div>
                </div>

                {/* Student Count Footer */}
                <div className="absolute bottom-3 left-4 text-white text-xs flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-amber-300" />
                  <span>{course.enrolledCount} active students</span>
                </div>
              </div>

              {/* Course Info */}
              <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between space-y-6">
                <div className="space-y-3">
                  <h3
                    onClick={() => handleOpenCourse(course)}
                    className="font-serif text-xl sm:text-2xl font-bold text-[#2C1E16] hover:text-[#F26C22] transition-colors cursor-pointer"
                  >
                    {course.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                    {course.subtitle}
                  </p>

                  {/* Highlights Bullet List */}
                  <div className="pt-2 space-y-1.5">
                    {course.whatYouLearn.slice(0, 3).map((item, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-stone-700">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Pricing & CTA */}
                <div className="pt-4 border-t border-stone-100 flex items-center justify-between gap-4">
                  <div>
                    <div className="text-[10px] text-stone-400 uppercase tracking-wider font-semibold">
                      Enrollment Fee
                    </div>
                    <div className="flex items-baseline gap-2">
                      <span className="font-serif text-2xl font-bold text-[#2C1E16] tabular-nums">
                        {formatNaira(course.price)}
                      </span>
                      {course.originalPrice > course.price && (
                        <span className="text-xs text-stone-400 line-through tabular-nums">
                          {formatNaira(course.originalPrice)}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <a
                      href={generateCourseEnrollmentWhatsAppUrl(course.title, course.price)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-3 rounded-xl border border-stone-200 text-stone-700 hover:text-[#25D366] hover:border-[#25D366] hover:bg-emerald-50 transition-colors"
                      title="Enroll on WhatsApp"
                      aria-label="Enroll on WhatsApp"
                    >
                      <MessageCircle className="w-4 h-4" />
                    </a>

                    <button
                      onClick={() => handleOpenCourse(course)}
                      className="px-5 py-3 bg-[#2C1E16] hover:bg-[#F26C22] text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 active:scale-95 shadow-xs"
                    >
                      <span>View Syllabus &amp; Enroll</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Course Detail Modal (Syllabus, Bio, Video Preview & Checkout) */}
      {activeCourseModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200 animate-in fade-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="p-6 bg-[#2C1E16] text-white flex items-start justify-between">
              <div>
                <span className="text-[10px] uppercase tracking-widest text-[#F26C22] font-bold">
                  {activeCourseModal.level} · {activeCourseModal.duration}
                </span>
                <h3 className="font-serif text-xl sm:text-2xl font-bold mt-1">
                  {activeCourseModal.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveCourseModal(null)}
                className="p-1 rounded-full text-white/70 hover:text-white"
                aria-label="Close modal"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 sm:p-8 space-y-6">
              {/* Instructor Bio Snippet */}
              <div className="flex items-center gap-4 p-4 bg-[#F7F4EE] rounded-2xl border border-stone-200">
                <img
                  src={settings?.chefPhotoUrl || '/photo-1577219491135-ce391730fb2c.jpg'}
                  alt="Chief Chef Adaeze Awiri"
                  className="w-12 h-12 rounded-full object-cover object-top border-2 border-[#F26C22] shadow-xs shrink-0"
                  onError={(e) => {
                    const target = e.currentTarget as HTMLImageElement;
                    if (!target.src.includes('photo-1577219491135-ce391730fb2c.jpg')) {
                      target.src = '/photo-1577219491135-ce391730fb2c.jpg';
                    }
                  }}
                />
                <div>
                  <h4 className="text-xs font-bold text-[#2C1E16]">
                    Instructor: Chief Chef Adaeze Awiri
                  </h4>
                  <p className="text-[11px] text-stone-600">
                    Master Baker with over a decade in Lagos luxury cake production. Direct personal mentorship throughout your coursework.
                  </p>
                </div>
              </div>

              {/* Syllabus Breakdown */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700">
                  Comprehensive Course Curriculum:
                </h4>
                <div className="space-y-2">
                  {activeCourseModal.syllabus.map((mod, i) => (
                    <div key={i} className="border border-stone-200 rounded-xl p-3 bg-stone-50">
                      <div className="font-semibold text-xs text-[#2C1E16] mb-1.5">
                        {mod.moduleTitle}
                      </div>
                      <ul className="space-y-1">
                        {mod.lessons.map((lesson, lIdx) => (
                          <li key={lIdx} className="text-[11px] text-stone-600 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#F26C22]" />
                            <span>{lesson}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>

              {/* Student Enrollment Form */}
              <div className="pt-4 border-t border-stone-200 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-serif text-lg font-bold text-[#2C1E16]">
                      Instant Enrollment
                    </h4>
                    <p className="text-xs text-stone-500">
                      Total Course Fee: <strong className="text-[#F26C22] text-sm">{formatNaira(activeCourseModal.price)}</strong>
                    </p>
                  </div>
                  <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2.5 py-1 rounded-md">
                    Instant Access
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Student Full Name *"
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    className="w-full text-xs border border-stone-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-[#F26C22]"
                  />
                  <input
                    type="tel"
                    placeholder="WhatsApp Phone Number *"
                    value={studentPhone}
                    onChange={(e) => setStudentPhone(e.target.value)}
                    className="w-full text-xs border border-stone-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-[#F26C22]"
                  />
                </div>
                <input
                  type="email"
                  placeholder="Student Email (for course manual delivery)"
                  value={studentEmail}
                  onChange={(e) => setStudentEmail(e.target.value)}
                  className="w-full text-xs border border-stone-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-[#F26C22]"
                />

                <div className="flex flex-col sm:flex-row gap-3 pt-2">
                  <button
                    onClick={() => handleEnrollCheckout(activeCourseModal)}
                    disabled={isProcessingEnrollment}
                    className="flex-1 py-3.5 bg-[#2C1E16] hover:bg-[#3D2B20] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-transform active:scale-95 disabled:opacity-50"
                  >
                    <CreditCard className="w-4 h-4 text-[#F26C22]" />
                    <span>{isProcessingEnrollment ? 'Authorizing Enrollment...' : `Pay ${formatNaira(activeCourseModal.price)} & Unlock Course`}</span>
                  </button>

                  <a
                    href={generateCourseEnrollmentWhatsAppUrl(activeCourseModal.title, activeCourseModal.price)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-3.5 px-6 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-transform active:scale-95"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Enroll on WhatsApp</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Enrollment Success Notification */}
      {enrolledSuccessCourse && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-8 text-center space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="font-serif text-2xl font-bold text-[#2C1E16]">
              Enrollment Successful!
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Congratulations, {studentName}! You have been registered in <strong>{enrolledSuccessCourse.title}</strong>. Your Student Access Code is <code className="bg-stone-100 px-2 py-0.5 rounded text-[#F26C22] font-bold">ADA-STU-{Math.floor(1000 + Math.random() * 9000)}</code>.
            </p>
            <div className="pt-2 flex flex-col gap-2">
              <a
                href={`https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(
                  `Hello Chef Adaeze! I just enrolled in ${enrolledSuccessCourse.title} (Student: ${studentName}). Please add me to the student group!`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 bg-[#25D366] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                Join Student WhatsApp Group
              </a>
              <button
                onClick={() => setEnrolledSuccessCourse(null)}
                className="py-2.5 text-xs text-stone-600 hover:text-stone-900 font-semibold"
              >
                Close &amp; Return to Academy
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
