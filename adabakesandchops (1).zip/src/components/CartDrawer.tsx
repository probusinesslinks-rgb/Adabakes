import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Trash2, Plus, Minus, MessageCircle, CreditCard, ShieldCheck, CheckCircle2, ArrowRight } from 'lucide-react';
import { formatNaira, generateCartOrderWhatsAppUrl, WHATSAPP_PHONE } from '../utils/whatsapp';

export const CartDrawer: React.FC = () => {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    cartSubtotal,
    createOrder,
    settings,
  } = useApp();

  const [deliveryRegion, setDeliveryRegion] = useState<'pickup' | 'ikorodu' | 'mainland' | 'island'>('mainland');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [notes, setNotes] = useState('');
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [orderCompleteData, setOrderCompleteData] = useState<{
    orderNumber: string;
    total: number;
  } | null>(null);

  if (!isCartOpen) return null;

  const deliveryFee = settings.deliveryFees[deliveryRegion] ?? 3500;
  const grandTotal = cartSubtotal + deliveryFee;

  const handleWhatsAppCheckout = () => {
    if (!customerName.trim() || !customerPhone.trim()) {
      alert('Please enter your Name and WhatsApp phone number to continue.');
      return;
    }

    const orderNumber = 'ABC-ORD-' + Math.floor(1000 + Math.random() * 9000);

    // Save order to context
    createOrder({
      customerName,
      customerPhone,
      deliveryAddress: deliveryRegion === 'pickup' ? 'Self Pickup at Odogunyan Ikorodu' : deliveryAddress,
      deliveryRegion,
      deliveryFee,
      items: cart.map((i) => ({
        productId: i.product.id,
        productTitle: i.product.title,
        unitPrice: i.product.price,
        quantity: i.quantity,
        customization: i.customization,
      })),
      subtotal: cartSubtotal,
      total: grandTotal,
      paymentMethod: 'whatsapp_transfer',
      eventDate,
      notes,
    });

    const url = generateCartOrderWhatsAppUrl({
      orderNumber,
      customerName,
      customerPhone,
      deliveryAddress: deliveryRegion === 'pickup' ? 'Self Pickup at Odogunyan Ikorodu' : deliveryAddress,
      deliveryRegion,
      items: cart,
      subtotal: cartSubtotal,
      deliveryFee,
      total: grandTotal,
      eventDate,
      notes,
    });

    window.open(url, '_blank');
    setIsCartOpen(false);
  };

  const handleSimulatePayment = () => {
    if (!customerName.trim() || !customerPhone.trim()) {
      alert('Please enter your Name and Phone number to continue.');
      return;
    }

    setIsCheckingOut(true);

    setTimeout(() => {
      const newOrder = createOrder({
        customerName,
        customerPhone,
        deliveryAddress: deliveryRegion === 'pickup' ? 'Self Pickup at Odogunyan Ikorodu' : deliveryAddress,
        deliveryRegion,
        deliveryFee,
        items: cart.map((i) => ({
          productId: i.product.id,
          productTitle: i.product.title,
          unitPrice: i.product.price,
          quantity: i.quantity,
          customization: i.customization,
        })),
        subtotal: cartSubtotal,
        total: grandTotal,
        paymentMethod: 'paystack_online',
        eventDate,
        notes,
      });

      setIsCheckingOut(false);
      setOrderCompleteData({
        orderNumber: newOrder.orderNumber,
        total: newOrder.total,
      });
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-white h-full shadow-2xl flex flex-col justify-between overflow-y-auto animate-in slide-in-from-right duration-300">
        {/* Drawer Header */}
        <div className="p-5 border-b border-stone-200 flex items-center justify-between bg-[#2C1E16] text-white">
          <div>
            <h3 className="font-serif text-lg font-bold">Your Culinary Bag</h3>
            <p className="text-xs text-stone-300">
              {cart.length} {cart.length === 1 ? 'item' : 'items'} selected
            </p>
          </div>
          <button
            onClick={() => {
              setIsCartOpen(false);
              setOrderCompleteData(null);
            }}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Successful Order State */}
        {orderCompleteData ? (
          <div className="p-8 my-auto text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h4 className="font-serif text-2xl font-bold text-[#2C1E16]">
              Order Confirmed!
            </h4>
            <p className="text-xs uppercase tracking-wider text-stone-500 font-semibold">
              Order Reference #{orderCompleteData.orderNumber}
            </p>
            <p className="text-sm text-stone-600 leading-relaxed">
              Thank you, {customerName}! Your order of {formatNaira(orderCompleteData.total)} has been recorded at our Odogunyan, Ikorodu bakery. Chef Adaeze and the team are preparing your batch with care.
            </p>
            <div className="pt-4 flex flex-col gap-2">
              <a
                href={`https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(
                  `Hello Chef Adaeze! I just confirmed Order #${orderCompleteData.orderNumber} on your website and would like to track preparation.`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 bg-[#25D366] text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-2 shadow-sm"
              >
                <MessageCircle className="w-4 h-4" />
                Track Order on WhatsApp
              </a>
              <button
                onClick={() => {
                  setOrderCompleteData(null);
                  setIsCartOpen(false);
                }}
                className="py-2.5 text-xs text-stone-600 hover:text-stone-900 font-medium"
              >
                Close &amp; Continue Browsing
              </button>
            </div>
          </div>
        ) : cart.length === 0 ? (
          /* Empty State */
          <div className="p-12 text-center my-auto space-y-3">
            <div className="w-16 h-16 bg-stone-100 text-stone-400 rounded-full flex items-center justify-center mx-auto">
              <Trash2 className="w-7 h-7" />
            </div>
            <h4 className="font-serif text-xl font-bold text-stone-700">
              Your bag is currently empty
            </h4>
            <p className="text-xs text-stone-500 max-w-xs mx-auto">
              Explore our freshly baked pastries, signature celebration cakes, and crispy Lagos party small chops platters.
            </p>
            <button
              onClick={() => setIsCartOpen(false)}
              className="mt-4 px-5 py-2.5 bg-[#2C1E16] text-white rounded-lg text-xs font-semibold hover:bg-[#422d21] transition-colors"
            >
              Browse Menu
            </button>
          </div>
        ) : (
          /* Cart Items & Checkout Form */
          <div className="flex-1 p-5 space-y-6 overflow-y-auto">
            {/* Items List */}
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-stone-500 border-b border-stone-200 pb-2">
                <span>Selected Items</span>
                <button
                  onClick={clearCart}
                  className="text-red-500 hover:text-red-700 hover:underline"
                >
                  Clear All
                </button>
              </div>

              {cart.map((item) => (
                <div
                  key={item.product.id}
                  className="flex gap-3 bg-stone-50 p-3 rounded-xl border border-stone-200/80 items-center justify-between"
                >
                  <div className="w-16 h-16 rounded-lg bg-stone-200 overflow-hidden shrink-0">
                    <img
                      src={item.product.imageUrl}
                      alt={item.product.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.currentTarget as HTMLElement).style.display = 'none';
                      }}
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <h5 className="text-xs font-semibold text-[#2C1E16] line-clamp-1">
                      {item.product.title}
                    </h5>
                    <p className="text-xs font-bold text-[#F26C22] mt-0.5">
                      {formatNaira(item.product.price)}
                    </p>
                    {item.customization && (
                      <p className="text-[11px] text-stone-500 italic truncate">
                        "{item.customization}"
                      </p>
                    )}
                  </div>

                  {/* Quantity Stepper */}
                  <div className="flex items-center gap-1.5 shrink-0 bg-white border border-stone-200 rounded-lg p-1">
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                      className="p-1 text-stone-500 hover:text-stone-800 rounded-sm"
                      aria-label="Decrease quantity"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="text-xs font-semibold w-5 text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                      className="p-1 text-stone-500 hover:text-stone-800 rounded-sm"
                      aria-label="Increase quantity"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <button
                    onClick={() => removeFromCart(item.product.id)}
                    className="p-1.5 text-stone-400 hover:text-red-500 transition-colors"
                    aria-label="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            {/* Delivery Region Selection */}
            <div className="space-y-3 pt-2 border-t border-stone-200">
              <label className="text-xs font-bold uppercase tracking-wider text-stone-700 block">
                Delivery Location in Lagos:
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setDeliveryRegion('pickup')}
                  className={`p-2.5 rounded-lg border text-left transition-all ${
                    deliveryRegion === 'pickup'
                      ? 'border-[#2C1E16] bg-[#2C1E16] text-white font-semibold'
                      : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                  }`}
                >
                  <div className="font-medium">Odogunyan Studio</div>
                  <div className="text-[11px] opacity-80">Self Pickup (₦0)</div>
                </button>

                <button
                  type="button"
                  onClick={() => setDeliveryRegion('ikorodu')}
                  className={`p-2.5 rounded-lg border text-left transition-all ${
                    deliveryRegion === 'ikorodu'
                      ? 'border-[#2C1E16] bg-[#2C1E16] text-white font-semibold'
                      : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                  }`}
                >
                  <div className="font-medium">Ikorodu Local</div>
                  <div className="text-[11px] opacity-80">{formatNaira(settings.deliveryFees.ikorodu)}</div>
                </button>

                <button
                  type="button"
                  onClick={() => setDeliveryRegion('mainland')}
                  className={`p-2.5 rounded-lg border text-left transition-all ${
                    deliveryRegion === 'mainland'
                      ? 'border-[#2C1E16] bg-[#2C1E16] text-white font-semibold'
                      : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                  }`}
                >
                  <div className="font-medium">Lagos Mainland</div>
                  <div className="text-[11px] opacity-80">{formatNaira(settings.deliveryFees.mainland)}</div>
                </button>

                <button
                  type="button"
                  onClick={() => setDeliveryRegion('island')}
                  className={`p-2.5 rounded-lg border text-left transition-all ${
                    deliveryRegion === 'island'
                      ? 'border-[#2C1E16] bg-[#2C1E16] text-white font-semibold'
                      : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                  }`}
                >
                  <div className="font-medium">Lagos Island / Lekki</div>
                  <div className="text-[11px] opacity-80">{formatNaira(settings.deliveryFees.island)}</div>
                </button>
              </div>
            </div>

            {/* Customer Details Form */}
            <div className="space-y-3 pt-2 border-t border-stone-200">
              <label className="text-xs font-bold uppercase tracking-wider text-stone-700 block">
                Recipient Details:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="Full Name *"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full text-xs border border-stone-300 rounded-lg px-3 py-2 focus:outline-none focus:border-[#F26C22]"
                />
                <input
                  type="tel"
                  placeholder="WhatsApp Phone (e.g. 0816...) *"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full text-xs border border-stone-300 rounded-lg px-3 py-2 focus:outline-none focus:border-[#F26C22]"
                />
              </div>

              {deliveryRegion !== 'pickup' && (
                <input
                  type="text"
                  placeholder="Exact Street Address in Lagos *"
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  className="w-full text-xs border border-stone-300 rounded-lg px-3 py-2 focus:outline-none focus:border-[#F26C22]"
                />
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-stone-500 block mb-1">
                    Event / Delivery Date:
                  </label>
                  <input
                    type="date"
                    value={eventDate}
                    onChange={(e) => setEventDate(e.target.value)}
                    className="w-full text-xs border border-stone-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#F26C22]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-stone-500 block mb-1">
                    Special Inscription / Notes:
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Write 'Happy Birthday' on board"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full text-xs border border-stone-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#F26C22]"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Drawer Footer / Totals and Action */}
        {!orderCompleteData && cart.length > 0 && (
          <div className="p-5 border-t border-stone-200 bg-stone-50 space-y-3 shrink-0">
            {/* Price Breakdown */}
            <div className="space-y-1.5 text-xs text-stone-600">
              <div className="flex justify-between">
                <span>Items Subtotal</span>
                <span className="font-medium text-stone-900 tabular-nums">
                  {formatNaira(cartSubtotal)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Estimated Lagos Delivery</span>
                <span className="font-medium text-stone-900 tabular-nums">
                  {formatNaira(deliveryFee)}
                </span>
              </div>
              <div className="flex justify-between text-sm font-bold text-[#2C1E16] pt-1 border-t border-stone-200">
                <span>Total Amount</span>
                <span className="text-[#F26C22] tabular-nums text-base font-extrabold">
                  {formatNaira(grandTotal)}
                </span>
              </div>
            </div>

            {/* Direct 1-Click WhatsApp Order Button */}
            <button
              onClick={handleWhatsAppCheckout}
              className="w-full py-3.5 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-md transition-transform active:scale-98"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Complete Order on WhatsApp</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>

            {/* Paystack / Online Card Checkout */}
            <button
              onClick={handleSimulatePayment}
              disabled={isCheckingOut}
              className="w-full py-2.5 bg-[#2C1E16] hover:bg-[#3D2B20] text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              <CreditCard className="w-4 h-4 text-[#F26C22]" />
              <span>{isCheckingOut ? 'Processing Secure Payment...' : 'Pay with Card / Bank Transfer (Paystack)'}</span>
            </button>

            <div className="flex items-center justify-center gap-2 text-[10px] text-stone-500 pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Freshly baked upon confirmation · Safe delivery guaranteed</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
