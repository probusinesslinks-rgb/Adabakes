import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Product, Course, ContentPost, BookingStatus, OrderStatus } from '../types';
import { formatNaira, WHATSAPP_PHONE } from '../utils/whatsapp';
import { Logo } from './Logo';
import royalWeddingCakeImg from '../assets/images/royal_wedding_cake.jpg';
import {
  Shield,
  LayoutDashboard,
  ShoppingBag,
  Cake,
  GraduationCap,
  FileText,
  Settings,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Clock,
  MessageCircle,
  TrendingUp,
  Users,
  Eye,
  LogOut,
  Save,
  Search,
  Upload,
  Image as ImageIcon,
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    products,
    addProduct,
    updateProduct,
    deleteProduct,
    toggleProductAvailability,
    bookings,
    updateBookingStatus,
    updateBookingNotes,
    deleteBooking,
    orders,
    updateOrderStatus,
    courses,
    addCourse,
    updateCourse,
    posts,
    addPost,
    updatePost,
    deletePost,
    settings,
    updateSettings,
    isAdminAuthenticated,
    loginAdmin,
    logoutAdmin,
    navigateTo,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'analytics' | 'crm' | 'products' | 'courses' | 'posts' | 'settings'>('crm');
  const [passcode, setPasscode] = useState('');
  const [authError, setAuthError] = useState(false);

  // Modal / Form States
  const [isAddProductOpen, setIsAddProductOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    title: '',
    category: 'cakes',
    price: 35000,
    piecesOrServings: '',
    description: '',
    badge: '',
    imageUrl: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80',
    isAvailable: true,
  });

  const [isAddPostOpen, setIsAddPostOpen] = useState(false);
  const [newPost, setNewPost] = useState<Partial<ContentPost>>({
    title: '',
    slug: '',
    excerpt: '',
    content: '',
    mediaType: 'article',
    mediaUrl: '',
    readTime: '3 min read',
    tags: ['Lagos Catering', 'Cakes'],
    author: 'Chef Adaeze Awiri',
    imageUrl: royalWeddingCakeImg,
  });

  // Settings local state
  const [localSettings, setLocalSettings] = useState(settings);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');

  const handleChefPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        if (result) {
          setLocalSettings((prev) => ({
            ...prev,
            chefPhotoUrl: result,
          }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Authentication check
  if (!isAdminAuthenticated) {
    return (
      <div className="min-h-screen bg-[#2C1E16] flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl max-w-md w-full p-8 shadow-2xl border border-stone-200 text-center space-y-6 animate-in zoom-in-95">
          <div className="flex justify-center">
            <Logo size={68} showText={true} subtitle="Admin & Management CRM" />
          </div>
          <div>
            <p className="text-xs text-stone-500 mt-2">
              Enter your passcode or click Instant Demo Access to manage orders, catalog, and bookings.
            </p>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!loginAdmin(passcode)) {
                setAuthError(true);
              }
            }}
            className="space-y-4"
          >
            <div>
              <input
                type="password"
                placeholder="Enter Passcode (e.g. ada2026)"
                value={passcode}
                onChange={(e) => {
                  setPasscode(e.target.value);
                  setAuthError(false);
                }}
                className="w-full text-center text-sm tracking-widest border border-stone-300 rounded-xl px-4 py-3 focus:outline-none focus:border-[#F26C22]"
              />
              {authError && (
                <p className="text-xs text-red-500 mt-1.5">
                  Invalid passcode. Try 'ada2026' or click below.
                </p>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-[#2C1E16] hover:bg-[#3D2B20] text-white rounded-xl text-xs font-bold transition-all shadow-md"
            >
              Unlock Dashboard
            </button>
          </form>

          <div className="pt-2 border-t border-stone-200 flex flex-col gap-2">
            <button
              onClick={() => loginAdmin('ada2026')}
              className="text-xs font-semibold text-[#F26C22] hover:underline"
            >
              1-Click Demo Login (Instant Access)
            </button>
            <button
              onClick={() => navigateTo('home')}
              className="text-xs text-stone-400 hover:text-stone-700"
            >
              ← Return to Storefront
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Analytics totals
  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const totalStudents = courses.reduce((sum, c) => sum + c.enrolledCount, 0);
  const activeInquiriesCount = bookings.filter((b) => b.status !== 'delivered').length;

  return (
    <div className="min-h-screen bg-stone-100 flex flex-col">
      {/* Top Admin Navbar */}
      <header className="bg-[#2C1E16] text-white border-b border-stone-800 px-4 sm:px-6 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Logo size={42} showText={true} variant="light" subtitle="Admin CRM · Odogunyan Hub" />
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigateTo('home')}
            className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>View Storefront</span>
          </button>

          <button
            onClick={logoutAdmin}
            className="px-3 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-200 text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </header>

      {/* Main Admin Content Container */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Navigation Tabs */}
        <div className="bg-white p-2 rounded-2xl shadow-xs border border-stone-200 flex items-center gap-1 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('crm')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
              activeTab === 'crm'
                ? 'bg-[#2C1E16] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-50'
            }`}
          >
            <Cake className="w-4 h-4 text-[#F26C22]" />
            <span>Orders &amp; Cake CRM ({bookings.length + orders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
              activeTab === 'analytics'
                ? 'bg-[#2C1E16] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-50'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 text-[#F26C22]" />
            <span>Overview &amp; Metrics</span>
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
              activeTab === 'products'
                ? 'bg-[#2C1E16] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-50'
            }`}
          >
            <ShoppingBag className="w-4 h-4 text-[#F26C22]" />
            <span>Shop Products ({products.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('courses')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
              activeTab === 'courses'
                ? 'bg-[#2C1E16] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-50'
            }`}
          >
            <GraduationCap className="w-4 h-4 text-[#F26C22]" />
            <span>Academy Courses ({courses.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('posts')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
              activeTab === 'posts'
                ? 'bg-[#2C1E16] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-50'
            }`}
          >
            <FileText className="w-4 h-4 text-[#F26C22]" />
            <span>Content &amp; Blog ({posts.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
              activeTab === 'settings'
                ? 'bg-[#2C1E16] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-50'
            }`}
          >
            <Settings className="w-4 h-4 text-[#F26C22]" />
            <span>Settings &amp; Rates</span>
          </button>
        </div>

        {/* 1. KANBAN CRM TAB */}
        {activeTab === 'crm' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="font-serif text-2xl font-bold text-[#2C1E16]">
                  Order &amp; Custom Booking Kanban CRM
                </h2>
                <p className="text-xs text-stone-500">
                  Manage cake production lifecycle, customer WhatsApp direct contacts, and Lagos deliveries.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  Live Sync (WAT)
                </span>
              </div>
            </div>

            {/* Kanban Columns */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Col 1: New Inquiries */}
              <div className="bg-stone-200/70 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-stone-700 uppercase tracking-wider">
                  <span>1. New Inquiries</span>
                  <span className="bg-white px-2 py-0.5 rounded-full text-stone-900">
                    {bookings.filter((b) => b.status === 'new_inquiry').length}
                  </span>
                </div>

                <div className="space-y-3">
                  {bookings
                    .filter((b) => b.status === 'new_inquiry')
                    .map((booking) => (
                      <div
                        key={booking.id}
                        className="bg-white p-4 rounded-xl shadow-xs border border-stone-200 space-y-3 text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-[#F26C22]">
                            #{booking.bookingNumber}
                          </span>
                          <span className="text-[10px] text-stone-400">
                            {booking.eventType}
                          </span>
                        </div>

                        <div>
                          <h4 className="font-bold text-[#2C1E16] text-sm">
                            {booking.customerName}
                          </h4>
                          <p className="text-stone-500 text-[11px] mt-0.5">
                            📍 {booking.deliveryLocation}
                          </p>
                          <p className="text-stone-500 text-[11px]">
                            📅 Date: {booking.eventDate} ({booking.tierCount})
                          </p>
                          <p className="font-semibold text-stone-700 mt-1">
                            Budget: {booking.budgetRange}
                          </p>
                        </div>

                        <div className="pt-2 border-t border-stone-100 flex items-center justify-between gap-2">
                          <a
                            href={`https://wa.me/${booking.customerPhone.replace(/\D/g, '')}?text=${encodeURIComponent(
                              `Hello ${booking.customerName}, Chef Adaeze here from Ada Bakes and Chops regarding your ${booking.eventType} cake inquiry (${booking.tierCount}).`
                            )}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 bg-[#25D366] text-white rounded-lg flex items-center gap-1 text-[11px] font-semibold"
                            title="Chat with Customer"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            <span>WhatsApp</span>
                          </a>

                          <select
                            value={booking.status}
                            onChange={(e) => updateBookingStatus(booking.id, e.target.value as BookingStatus)}
                            className="text-[11px] bg-stone-100 border border-stone-300 rounded-lg p-1 text-stone-800"
                          >
                            <option value="new_inquiry">New</option>
                            <option value="quote_sent">Quote Sent</option>
                            <option value="in_baking">In Production</option>
                            <option value="delivered">Delivered</option>
                          </select>
                        </div>
                      </div>
                    ))}
                </div>
              </div>

              {/* Col 2: Quote Sent / Deposit Paid */}
              <div className="bg-stone-200/70 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-stone-700 uppercase tracking-wider">
                  <span>2. Quote Sent</span>
                  <span className="bg-white px-2 py-0.5 rounded-full text-stone-900">
                    {bookings.filter((b) => b.status === 'quote_sent').length}
                  </span>
                </div>

                <div className="space-y-3">
                  {bookings
                    .filter((b) => b.status === 'quote_sent')
                    .map((booking) => (
                      <div
                        key={booking.id}
                        className="bg-white p-4 rounded-xl shadow-xs border border-stone-200 space-y-3 text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-[#F26C22]">
                            #{booking.bookingNumber}
                          </span>
                          <span className="text-[10px] text-stone-400">
                            {booking.eventType}
                          </span>
                        </div>

                        <div>
                          <h4 className="font-bold text-[#2C1E16] text-sm">
                            {booking.customerName}
                          </h4>
                          <p className="text-stone-500 text-[11px] mt-0.5">
                            📍 {booking.deliveryLocation}
                          </p>
                          <p className="text-stone-500 text-[11px]">
                            📅 {booking.eventDate} ({booking.designStyle})
                          </p>
                        </div>

                        <div className="pt-2 border-t border-stone-100 flex items-center justify-between gap-2">
                          <a
                            href={`https://wa.me/${booking.customerPhone.replace(/\D/g, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 bg-[#25D366] text-white rounded-lg flex items-center gap-1 text-[11px] font-semibold"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            <span>Reply</span>
                          </a>

                          <select
                            value={booking.status}
                            onChange={(e) => updateBookingStatus(booking.id, e.target.value as BookingStatus)}
                            className="text-[11px] bg-stone-100 border border-stone-300 rounded-lg p-1 text-stone-800"
                          >
                            <option value="new_inquiry">New</option>
                            <option value="quote_sent">Quote Sent</option>
                            <option value="in_baking">Start Baking</option>
                            <option value="delivered">Delivered</option>
                          </select>
                        </div>
                      </div>
                    ))}
                </div>
              </div>

              {/* Col 3: In Production / Baking */}
              <div className="bg-stone-200/70 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-stone-700 uppercase tracking-wider">
                  <span>3. In Kitchen Baking</span>
                  <span className="bg-white px-2 py-0.5 rounded-full text-stone-900">
                    {bookings.filter((b) => b.status === 'in_baking').length +
                      orders.filter((o) => o.status === 'in_production').length}
                  </span>
                </div>

                <div className="space-y-3">
                  {/* Bookings */}
                  {bookings
                    .filter((b) => b.status === 'in_baking')
                    .map((booking) => (
                      <div
                        key={booking.id}
                        className="bg-amber-50/70 p-4 rounded-xl shadow-xs border border-amber-200 space-y-2 text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-amber-800">
                            #{booking.bookingNumber}
                          </span>
                          <span className="text-[10px] bg-amber-200 text-amber-900 px-1.5 py-0.5 rounded font-semibold">
                            In Oven / Stacking
                          </span>
                        </div>
                        <h4 className="font-bold text-[#2C1E16]">
                          {booking.customerName} ({booking.tierCount})
                        </h4>
                        <p className="text-[11px] text-stone-600">
                          Due: {booking.eventDate} · {booking.deliveryLocation}
                        </p>
                        {booking.adminNotes && (
                          <p className="text-[10px] bg-white p-1.5 rounded text-stone-700 italic border border-amber-200">
                            Notes: {booking.adminNotes}
                          </p>
                        )}

                        <div className="pt-2 border-t border-amber-200/60 flex items-center justify-between">
                          <select
                            value={booking.status}
                            onChange={(e) => updateBookingStatus(booking.id, e.target.value as BookingStatus)}
                            className="text-[11px] bg-white border border-stone-300 rounded p-1"
                          >
                            <option value="in_baking">In Baking</option>
                            <option value="delivered">Mark Delivered</option>
                          </select>
                        </div>
                      </div>
                    ))}

                  {/* Direct Orders */}
                  {orders
                    .filter((o) => o.status === 'in_production')
                    .map((order) => (
                      <div
                        key={order.id}
                        className="bg-white p-4 rounded-xl shadow-xs border border-stone-200 space-y-2 text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-stone-900">
                            #{order.orderNumber}
                          </span>
                          <span className="text-[10px] text-stone-500">Shop Order</span>
                        </div>
                        <h4 className="font-bold text-[#2C1E16]">
                          {order.customerName}
                        </h4>
                        <p className="text-[11px] text-[#F26C22] font-bold">
                          {formatNaira(order.total)}
                        </p>
                        <ul className="text-[11px] text-stone-600 list-disc pl-3">
                          {order.items.map((it, idx) => (
                            <li key={idx}>
                              {it.productTitle} x {it.quantity}
                            </li>
                          ))}
                        </ul>
                        <div className="pt-2 border-t border-stone-100 flex justify-end">
                          <button
                            onClick={() => updateOrderStatus(order.id, 'delivered')}
                            className="px-2.5 py-1 bg-emerald-600 text-white rounded text-[11px] font-semibold"
                          >
                            Mark Delivered
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              </div>

              {/* Col 4: Completed & Delivered */}
              <div className="bg-stone-200/70 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-stone-700 uppercase tracking-wider">
                  <span>4. Delivered / Closed</span>
                  <span className="bg-white px-2 py-0.5 rounded-full text-stone-900">
                    {bookings.filter((b) => b.status === 'delivered').length +
                      orders.filter((o) => o.status === 'delivered').length}
                  </span>
                </div>

                <div className="space-y-3">
                  {bookings
                    .filter((b) => b.status === 'delivered')
                    .map((booking) => (
                      <div
                        key={booking.id}
                        className="bg-emerald-50/70 p-3 rounded-xl border border-emerald-200 space-y-1 text-xs"
                      >
                        <span className="font-bold text-emerald-800">
                          #{booking.bookingNumber}
                        </span>
                        <h4 className="font-bold text-stone-800">
                          {booking.customerName}
                        </h4>
                        <p className="text-[11px] text-stone-500">
                          Delivered for {booking.eventType}
                        </p>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 2. OVERVIEW & ANALYTICS TAB */}
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            <h2 className="font-serif text-2xl font-bold text-[#2C1E16]">
              Business Performance &amp; Analytics
            </h2>

            {/* KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-2">
                <span className="text-xs uppercase font-bold text-stone-500">
                  Recorded Revenue
                </span>
                <div className="font-serif text-3xl font-extrabold text-[#2C1E16] tabular-nums">
                  {formatNaira(totalRevenue)}
                </div>
                <div className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>Verified Lagos Orders</span>
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-2">
                <span className="text-xs uppercase font-bold text-stone-500">
                  Total Orders
                </span>
                <div className="font-serif text-3xl font-extrabold text-[#2C1E16] tabular-nums">
                  {orders.length}
                </div>
                <div className="text-[11px] text-stone-500">
                  Direct menu purchases
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-2">
                <span className="text-xs uppercase font-bold text-stone-500">
                  Custom Cake Inquiries
                </span>
                <div className="font-serif text-3xl font-extrabold text-[#F26C22] tabular-nums">
                  {bookings.length}
                </div>
                <div className="text-[11px] text-stone-500">
                  {activeInquiriesCount} in active progress
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-2">
                <span className="text-xs uppercase font-bold text-stone-500">
                  Academy Students
                </span>
                <div className="font-serif text-3xl font-extrabold text-[#2C1E16] tabular-nums">
                  {totalStudents}
                </div>
                <div className="text-[11px] text-stone-500">
                  Enrolled across 4 courses
                </div>
              </div>
            </div>

            {/* Recent Orders Table */}
            <div className="bg-white rounded-2xl border border-stone-200 p-6 space-y-4">
              <h3 className="font-serif text-lg font-bold text-[#2C1E16]">
                Recent Direct Orders
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="bg-stone-50 text-stone-500 uppercase font-semibold">
                    <tr>
                      <th className="p-3">Order #</th>
                      <th className="p-3">Customer</th>
                      <th className="p-3">Region</th>
                      <th className="p-3">Amount</th>
                      <th className="p-3">Method</th>
                      <th className="p-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {orders.map((ord) => (
                      <tr key={ord.id} className="hover:bg-stone-50/50">
                        <td className="p-3 font-bold text-[#2C1E16]">{ord.orderNumber}</td>
                        <td className="p-3">
                          <div className="font-medium">{ord.customerName}</div>
                          <div className="text-[10px] text-stone-400">{ord.customerPhone}</div>
                        </td>
                        <td className="p-3 capitalize">{ord.deliveryRegion}</td>
                        <td className="p-3 font-bold text-[#F26C22] tabular-nums">
                          {formatNaira(ord.total)}
                        </td>
                        <td className="p-3 uppercase text-[10px] font-semibold text-stone-600">
                          {ord.paymentMethod.replace('_', ' ')}
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                            {ord.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* 3. SHOP PRODUCTS CATALOG CMS */}
        {activeTab === 'products' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-serif text-2xl font-bold text-[#2C1E16]">
                  Shop &amp; Menu Catalog CMS
                </h2>
                <p className="text-xs text-stone-500">
                  Add, edit prices, descriptions, and availability for all bakery and small chops items.
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingProduct(null);
                  setIsAddProductOpen(true);
                }}
                className="px-4 py-2.5 bg-[#2C1E16] hover:bg-[#3D2B20] text-white rounded-xl text-xs font-bold flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Product</span>
              </button>
            </div>

            {/* Products List Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {products.map((p) => (
                <div
                  key={p.id}
                  className="bg-white rounded-2xl p-4 border border-stone-200 shadow-xs flex gap-3 justify-between"
                >
                  <div className="w-20 h-20 rounded-xl bg-stone-100 overflow-hidden shrink-0">
                    <img
                      src={p.imageUrl}
                      alt={p.title}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="flex-1 min-w-0 space-y-1">
                    <span className="text-[10px] uppercase font-bold text-[#F26C22]">
                      {p.category.replace('_', ' ')}
                    </span>
                    <h4 className="font-bold text-xs text-[#2C1E16] truncate">
                      {p.title}
                    </h4>
                    <p className="font-serif text-sm font-bold text-[#2C1E16] tabular-nums">
                      {formatNaira(p.price)}
                    </p>

                    <div className="pt-2 flex items-center gap-2">
                      <button
                        onClick={() => toggleProductAvailability(p.id)}
                        className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                          p.isAvailable
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {p.isAvailable ? 'In Stock' : 'Sold Out'}
                      </button>

                      <button
                        onClick={() => deleteProduct(p.id)}
                        className="text-stone-400 hover:text-red-600 p-1"
                        aria-label="Delete product"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Add Product Modal */}
            {isAddProductOpen && (
              <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
                  <h3 className="font-serif text-xl font-bold text-[#2C1E16]">
                    Add New Menu Product
                  </h3>
                  <div className="space-y-3 text-xs">
                    <div>
                      <label className="font-bold block mb-1">Product Title</label>
                      <input
                        type="text"
                        value={newProduct.title}
                        onChange={(e) => setNewProduct({ ...newProduct, title: e.target.value })}
                        placeholder="e.g. Royal Red Velvet Slice Box"
                        className="w-full border border-stone-300 rounded-lg p-2"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="font-bold block mb-1">Category</label>
                        <select
                          value={newProduct.category}
                          onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value as any })}
                          className="w-full border border-stone-300 rounded-lg p-2"
                        >
                          <option value="cakes">Cakes</option>
                          <option value="small_chops">Small Chops</option>
                          <option value="pastries">Pastries</option>
                          <option value="celebration">Celebration</option>
                        </select>
                      </div>

                      <div>
                        <label className="font-bold block mb-1">Price (NGN)</label>
                        <input
                          type="number"
                          value={newProduct.price}
                          onChange={(e) => setNewProduct({ ...newProduct, price: Number(e.target.value) })}
                          className="w-full border border-stone-300 rounded-lg p-2"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="font-bold block mb-1">Pieces / Servings</label>
                      <input
                        type="text"
                        value={newProduct.piecesOrServings}
                        onChange={(e) => setNewProduct({ ...newProduct, piecesOrServings: e.target.value })}
                        placeholder="e.g. Box of 10 / Feeds 8"
                        className="w-full border border-stone-300 rounded-lg p-2"
                      />
                    </div>

                    <div>
                      <label className="font-bold block mb-1">Description</label>
                      <textarea
                        rows={2}
                        value={newProduct.description}
                        onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                        className="w-full border border-stone-300 rounded-lg p-2"
                      />
                    </div>

                    <div>
                      <label className="font-bold block mb-1">Image URL</label>
                      <input
                        type="text"
                        value={newProduct.imageUrl}
                        onChange={(e) => setNewProduct({ ...newProduct, imageUrl: e.target.value })}
                        className="w-full border border-stone-300 rounded-lg p-2"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      onClick={() => setIsAddProductOpen(false)}
                      className="px-4 py-2 border rounded-lg text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        if (!newProduct.title) return;
                        addProduct({
                          title: newProduct.title!,
                          slug: newProduct.title!.toLowerCase().replace(/\s+/g, '-'),
                          category: newProduct.category as any,
                          price: newProduct.price || 25000,
                          piecesOrServings: newProduct.piecesOrServings,
                          description: newProduct.description || '',
                          badge: newProduct.badge,
                          imageUrl: newProduct.imageUrl || '',
                          isAvailable: true,
                        });
                        setIsAddProductOpen(false);
                      }}
                      className="px-5 py-2 bg-[#2C1E16] text-white rounded-lg text-xs font-bold"
                    >
                      Save Product
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 4. COURSES CMS TAB */}
        {activeTab === 'courses' && (
          <div className="space-y-6">
            <h2 className="font-serif text-2xl font-bold text-[#2C1E16]">
              Baking Academy Course Catalog
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {courses.map((crs) => (
                <div
                  key={crs.id}
                  className="bg-white p-5 rounded-2xl border border-stone-200 space-y-3 text-xs"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[10px] font-bold text-[#F26C22] uppercase">
                        {crs.level}
                      </span>
                      <h4 className="font-bold text-sm text-[#2C1E16]">
                        {crs.title}
                      </h4>
                    </div>
                    <span className="font-serif font-bold text-base text-[#2C1E16] tabular-nums">
                      {formatNaira(crs.price)}
                    </span>
                  </div>

                  <p className="text-stone-600 line-clamp-2">
                    {crs.subtitle}
                  </p>

                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-stone-500">
                    <span>{crs.enrolledCount} active students</span>
                    <span>{crs.duration}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 5. POSTS CMS TAB */}
        {activeTab === 'posts' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-serif text-2xl font-bold text-[#2C1E16]">
                  Content Hub &amp; Blog CMS
                </h2>
                <p className="text-xs text-stone-500">
                  Publish recipes, YouTube tutorials, and baking science articles.
                </p>
              </div>

              <button
                onClick={() => setIsAddPostOpen(true)}
                className="px-4 py-2.5 bg-[#2C1E16] hover:bg-[#3D2B20] text-white rounded-xl text-xs font-bold flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Publish New Post</span>
              </button>
            </div>

            <div className="space-y-3">
              {posts.map((post) => (
                <div
                  key={post.id}
                  className="bg-white p-4 rounded-xl border border-stone-200 flex items-center justify-between text-xs"
                >
                  <div className="space-y-0.5">
                    <span className="text-[10px] uppercase font-bold text-[#F26C22]">
                      {post.mediaType} · {post.publishedDate}
                    </span>
                    <h4 className="font-bold text-sm text-[#2C1E16]">
                      {post.title}
                    </h4>
                    <p className="text-stone-500 line-clamp-1">{post.excerpt}</p>
                  </div>

                  <button
                    onClick={() => deletePost(post.id)}
                    className="p-2 text-stone-400 hover:text-red-600"
                    aria-label="Delete post"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add Post Modal */}
            {isAddPostOpen && (
              <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
                  <h3 className="font-serif text-xl font-bold text-[#2C1E16]">
                    Publish New Kitchen Post
                  </h3>
                  <div className="space-y-3 text-xs">
                    <div>
                      <label className="font-bold block mb-1">Post Title</label>
                      <input
                        type="text"
                        value={newPost.title}
                        onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                        className="w-full border border-stone-300 rounded-lg p-2"
                      />
                    </div>
                    <div>
                      <label className="font-bold block mb-1">Excerpt</label>
                      <textarea
                        rows={2}
                        value={newPost.excerpt}
                        onChange={(e) => setNewPost({ ...newPost, excerpt: e.target.value })}
                        className="w-full border border-stone-300 rounded-lg p-2"
                      />
                    </div>
                    <div>
                      <label className="font-bold block mb-1">Full Article / Recipe Body</label>
                      <textarea
                        rows={4}
                        value={newPost.content}
                        onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                        className="w-full border border-stone-300 rounded-lg p-2"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="font-bold block mb-1">Media Type</label>
                        <select
                          value={newPost.mediaType}
                          onChange={(e) => setNewPost({ ...newPost, mediaType: e.target.value as any })}
                          className="w-full border border-stone-300 rounded-lg p-2"
                        >
                          <option value="article">Article</option>
                          <option value="youtube">YouTube</option>
                          <option value="tiktok">TikTok</option>
                        </select>
                      </div>
                      <div>
                        <label className="font-bold block mb-1">Video Link (Optional)</label>
                        <input
                          type="text"
                          value={newPost.mediaUrl}
                          onChange={(e) => setNewPost({ ...newPost, mediaUrl: e.target.value })}
                          className="w-full border border-stone-300 rounded-lg p-2"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      onClick={() => setIsAddPostOpen(false)}
                      className="px-4 py-2 border rounded-lg text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        if (!newPost.title) return;
                        addPost({
                          title: newPost.title!,
                          slug: newPost.title!.toLowerCase().replace(/\s+/g, '-'),
                          excerpt: newPost.excerpt || '',
                          content: newPost.content || '',
                          mediaType: newPost.mediaType as any,
                          mediaUrl: newPost.mediaUrl,
                          readTime: newPost.readTime || '3 min read',
                          tags: ['Baking', 'Lagos'],
                          author: 'Chef Adaeze Awiri',
                          imageUrl: newPost.imageUrl || royalWeddingCakeImg,
                        });
                        setIsAddPostOpen(false);
                      }}
                      className="px-5 py-2 bg-[#2C1E16] text-white rounded-lg text-xs font-bold"
                    >
                      Publish
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 6. SETTINGS TAB */}
        {activeTab === 'settings' && (
          <div className="bg-white rounded-2xl border border-stone-200 p-6 space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-stone-200">
              <div>
                <h2 className="font-serif text-2xl font-bold text-[#2C1E16]">
                  Bakery Settings &amp; Delivery Rates
                </h2>
                <p className="text-xs text-stone-500">
                  Update operational parameters, chef portrait, announcement bar, and Lagos delivery fees.
                </p>
              </div>

              <button
                onClick={() => {
                  updateSettings(localSettings);
                  setSaveSuccessMsg('Settings and Chef Portrait saved successfully!');
                  setTimeout(() => setSaveSuccessMsg(''), 4000);
                }}
                className="px-5 py-2.5 bg-[#F26C22] hover:bg-[#d95914] text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-sm"
              >
                <Save className="w-4 h-4" />
                <span>Save Changes</span>
              </button>
            </div>

            {saveSuccessMsg && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-2 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{saveSuccessMsg}</span>
              </div>
            )}

            <div className="space-y-6 text-xs">
              {/* Founder & Chief Chef Portrait Section */}
              <div className="p-4 bg-[#F7F4EE] rounded-2xl border border-stone-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-[#2C1E16] flex items-center gap-2">
                      <ImageIcon className="w-4 h-4 text-[#F26C22]" />
                      Founder &amp; Chief Chef Portrait (Chef Adaeze Awiri)
                    </h3>
                    <p className="text-xs text-stone-500">
                      Upload Ada Awiri&apos;s photo from your computer/phone or enter an image URL.
                    </p>
                  </div>
                  {localSettings.chefPhotoUrl && (
                    <button
                      type="button"
                      onClick={() => setLocalSettings({ ...localSettings, chefPhotoUrl: '/photo-1577219491135-ce391730fb2c.jpg' })}
                      className="text-xs text-[#F26C22] hover:underline font-semibold"
                    >
                      Reset to Default Chef Photo
                    </button>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 pt-1">
                  <div className="relative w-20 h-24 rounded-xl overflow-hidden bg-stone-200 border-2 border-white shadow-md shrink-0">
                    <img
                      src={localSettings.chefPhotoUrl || '/photo-1577219491135-ce391730fb2c.jpg'}
                      alt="Chef Adaeze Awiri Preview"
                      className="w-full h-full object-cover object-top"
                    />
                  </div>

                  <div className="flex-1 space-y-2 w-full">
                    <div>
                      <span className="block text-xs font-bold text-stone-700 mb-1">
                        Upload Image File:
                      </span>
                      <label className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-stone-300 rounded-xl text-xs font-semibold text-stone-700 hover:bg-stone-50 cursor-pointer shadow-xs transition-colors">
                        <Upload className="w-4 h-4 text-[#F26C22]" />
                        <span>Choose Photo from Device...</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleChefPhotoUpload}
                          className="hidden"
                        />
                      </label>
                    </div>

                    <div>
                      <span className="block text-xs font-bold text-stone-700 mb-1">
                        Or Image URL:
                      </span>
                      <input
                        type="text"
                        value={localSettings.chefPhotoUrl || ''}
                        placeholder="/photo-1577219491135-ce391730fb2c.jpg"
                        onChange={(e) => setLocalSettings({ ...localSettings, chefPhotoUrl: e.target.value })}
                        className="w-full border border-stone-300 rounded-xl p-2.5 text-xs bg-white"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="font-bold text-stone-700 block">
                  Top Announcement Banner:
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    value={localSettings.announcementText}
                    onChange={(e) => setLocalSettings({ ...localSettings, announcementText: e.target.value })}
                    className="flex-1 border border-stone-300 rounded-xl p-2.5"
                  />
                  <label className="flex items-center gap-1.5 font-semibold text-stone-700">
                    <input
                      type="checkbox"
                      checked={localSettings.announcementEnabled}
                      onChange={(e) => setLocalSettings({ ...localSettings, announcementEnabled: e.target.checked })}
                    />
                    <span>Enabled</span>
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    Ikorodu Local Delivery (₦)
                  </label>
                  <input
                    type="number"
                    value={localSettings.deliveryFees.ikorodu}
                    onChange={(e) =>
                      setLocalSettings({
                        ...localSettings,
                        deliveryFees: { ...localSettings.deliveryFees, ikorodu: Number(e.target.value) },
                      })
                    }
                    className="w-full border border-stone-300 rounded-xl p-2.5"
                  />
                </div>

                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    Lagos Mainland Fee (₦)
                  </label>
                  <input
                    type="number"
                    value={localSettings.deliveryFees.mainland}
                    onChange={(e) =>
                      setLocalSettings({
                        ...localSettings,
                        deliveryFees: { ...localSettings.deliveryFees, mainland: Number(e.target.value) },
                      })
                    }
                    className="w-full border border-stone-300 rounded-xl p-2.5"
                  />
                </div>

                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    Lagos Island / Lekki Fee (₦)
                  </label>
                  <input
                    type="number"
                    value={localSettings.deliveryFees.island}
                    onChange={(e) =>
                      setLocalSettings({
                        ...localSettings,
                        deliveryFees: { ...localSettings.deliveryFees, island: Number(e.target.value) },
                      })
                    }
                    className="w-full border border-stone-300 rounded-xl p-2.5"
                  />
                </div>
              </div>

              <div className="pt-2">
                <label className="font-bold text-stone-700 block mb-1">
                  Operating Hours Display
                </label>
                <input
                  type="text"
                  value={localSettings.operatingHours}
                  onChange={(e) => setLocalSettings({ ...localSettings, operatingHours: e.target.value })}
                  className="w-full border border-stone-300 rounded-xl p-2.5"
                />
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">
                  Bakery Physical Address
                </label>
                <input
                  type="text"
                  value={localSettings.address}
                  onChange={(e) => setLocalSettings({ ...localSettings, address: e.target.value })}
                  className="w-full border border-stone-300 rounded-xl p-2.5"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
