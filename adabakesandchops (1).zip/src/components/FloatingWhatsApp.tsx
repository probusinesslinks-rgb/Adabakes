import React, { useState } from 'react';
import { MessageCircle, X, Send, Cake, Sparkles } from 'lucide-react';
import { WHATSAPP_PHONE } from '../utils/whatsapp';
import { useApp } from '../context/AppContext';
import { Logo } from './Logo';

export const FloatingWhatsApp: React.FC = () => {
  const { navigateTo } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [customMsg, setCustomMsg] = useState('');

  const quickPrompts = [
    'I want to inquire about custom wedding cake pricing',
    'I need small chops for an upcoming party in Lagos',
    'How do I enroll in the online baking masterclasses?',
    'What is your delivery fee to my location in Lagos?',
  ];

  const handleSend = (text: string) => {
    const encoded = encodeURIComponent(text.trim() || 'Hello Chef Adaeze, I would like to make an inquiry.');
    window.open(`https://wa.me/${WHATSAPP_PHONE}?text=${encoded}`, '_blank');
    setIsOpen(false);
    setCustomMsg('');
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Expanded Quick Chat Card */}
      {isOpen && (
        <div className="mb-3 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200">
          {/* Header */}
          <div className="bg-[#2C1E16] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Logo size={42} />
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-[#2C1E16] rounded-full" />
              </div>
              <div>
                <h4 className="font-semibold text-sm leading-tight">Chef Adaeze Awiri</h4>
                <p className="text-[11px] text-[#FAFAFA]/75 flex items-center gap-1">
                  Ada Bakes &amp; Chops · Typically replies in 5 mins
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white/70 hover:text-white p-1 rounded-full"
              aria-label="Close WhatsApp chat"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="p-4 bg-stone-50 space-y-3 max-h-80 overflow-y-auto">
            <div className="bg-white p-3 rounded-xl rounded-tl-none shadow-xs border border-stone-100 text-xs text-stone-800 space-y-1">
              <p className="font-medium text-[#2C1E16]">
                Welcome to Ada Bakes and Chops! 👩‍🍳
              </p>
              <p className="text-stone-600 leading-relaxed">
                We craft bespoke luxury cakes and crunchy party small chops in Odogunyan, Ikorodu and deliver all across Lagos State. How can we sweeten your celebration today?
              </p>
            </div>

            <div className="space-y-1.5 pt-1">
              <p className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
                Quick Inquiries:
              </p>
              {quickPrompts.map((prompt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSend(prompt)}
                  className="w-full text-left text-xs bg-white hover:bg-orange-50 border border-stone-200 hover:border-[#F26C22]/40 rounded-lg p-2 transition-colors text-stone-700 hover:text-[#2C1E16] flex items-center justify-between group"
                >
                  <span className="truncate">{prompt}</span>
                  <span className="text-[#F26C22] opacity-0 group-hover:opacity-100 transition-opacity ml-1 shrink-0 font-bold">
                    →
                  </span>
                </button>
              ))}
            </div>

            <div className="pt-2 border-t border-stone-200/60 flex items-center justify-between text-[11px]">
              <button
                onClick={() => {
                  setIsOpen(false);
                  navigateTo('custom-order');
                }}
                className="text-[#F26C22] font-semibold hover:underline flex items-center gap-1"
              >
                <Cake className="w-3.5 h-3.5" />
                Custom Cake Builder
              </button>
              <span className="text-stone-400">Office: Odogunyan, Ikorodu</span>
            </div>
          </div>

          {/* Input & Send Footer */}
          <div className="p-3 bg-white border-t border-stone-200 flex items-center gap-2">
            <input
              type="text"
              value={customMsg}
              onChange={(e) => setCustomMsg(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSend(customMsg);
              }}
              placeholder="Type your message..."
              className="flex-1 text-xs border border-stone-300 rounded-lg px-3 py-2 focus:outline-none focus:border-[#F26C22]"
            />
            <button
              onClick={() => handleSend(customMsg)}
              className="bg-[#25D366] hover:bg-[#20ba59] text-white p-2 rounded-lg transition-colors flex items-center justify-center shrink-0"
              aria-label="Send WhatsApp message"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Floating Launcher Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="group relative flex items-center gap-3 bg-[#25D366] hover:bg-[#20ba59] text-white px-4 py-3 rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 active:scale-95 focus:outline-none"
        aria-label="Open WhatsApp chat with Chef Adaeze"
      >
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
        </span>
        <MessageCircle className="w-6 h-6" />
        <span className="text-sm font-semibold tracking-wide hidden sm:inline">
          Chat on WhatsApp
        </span>
      </button>
    </div>
  );
};
