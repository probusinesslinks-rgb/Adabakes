import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ShoppingBag, MessageCircle, Menu, X, Shield, PhoneCall } from 'lucide-react';
import { WHATSAPP_PHONE } from '../utils/whatsapp';
import { Logo } from './Logo';

export const Header: React.FC = () => {
  const { activePage, navigateTo, cartTotalCount, setIsCartOpen, settings } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [bannerVisible, setBannerVisible] = useState(true);

  const navLinks = [
    { label: 'Home', page: 'home' as const },
    { label: 'Menu & Shop', page: 'menu' as const },
    { label: 'Custom Cakes', page: 'custom-order' as const },
    { label: 'Baking Academy', page: 'academy' as const },
    { label: 'Kitchen Tales', page: 'content' as const },
    { label: 'About', page: 'about' as const },
    { label: 'Contact', page: 'contact' as const },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#FAFAFA]/95 backdrop-blur-md border-b border-[#2C1E16]/10 transition-colors">
      {/* Optional Top Announcement Bar (150% scaled text) */}
      {settings.announcementEnabled && bannerVisible && (
        <div className="bg-[#2C1E16] text-[#FAFAFA] text-[18px] py-3 px-4 text-center flex items-center justify-between transition-all">
          <div className="flex-1 text-center font-medium tracking-wide">
            {settings.announcementText}
          </div>
          <button
            onClick={() => setBannerVisible(false)}
            className="text-stone-400 hover:text-white p-1 text-base shrink-0 ml-2"
            aria-label="Dismiss banner"
          >
            ✕
          </button>
        </div>
      )}

      {/* Main 3-Zone Navigation Bar - Expanded height to fit 150% scaled logo and typography */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 min-h-[96px] sm:min-h-[104px] lg:min-h-[114px] py-3 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Title / Wordmark (150% scaled across Screen, Tablet, and Mobile views) */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => navigateTo('home')}
            className="text-left group flex items-center focus:outline-none cursor-pointer"
            aria-label="Ada Bakes and Chops Home"
          >
            <Logo showText={true} scale={1.5} />
          </button>
        </div>

        {/* Zone 2: Navigation Links (150% scaled text: 21px) */}
        <nav className="hidden lg:flex items-center gap-5 xl:gap-8">
          {navLinks.map((link) => {
            const isActive = activePage === link.page;
            return (
              <button
                key={link.page}
                onClick={() => navigateTo(link.page)}
                className={`text-[17px] xl:text-[21px] font-medium tracking-normal transition-colors py-1.5 relative whitespace-nowrap ${
                  isActive
                    ? 'text-[#F26C22] font-semibold'
                    : 'text-[#2C1E16]/80 hover:text-[#F26C22]'
                }`}
              >
                {link.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-1 bg-[#F26C22] rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Actions (150% scaled buttons, icons, and text) */}
        <div className="flex items-center gap-2 sm:gap-3.5">
          {/* Quick WhatsApp Action (150% scaled: 18px text, 24px icon) */}
          <a
            href={`https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(
              'Hello Chef Adaeze! I would like to make an inquiry with Ada Bakes and Chops.'
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-2.5 px-5 py-3 text-[18px] font-semibold text-white bg-[#F26C22] hover:bg-[#d95914] rounded-xl shadow-sm transition-all whitespace-nowrap active:scale-95"
          >
            <MessageCircle className="w-6 h-6" />
            <span>Order on WhatsApp</span>
          </a>

          {/* Cart Bag Icon with 150% count badge */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative p-3 rounded-xl text-[#2C1E16] hover:bg-[#2C1E16]/5 transition-colors focus:outline-none"
            aria-label="View shopping cart"
          >
            <ShoppingBag className="w-7 h-7" />
            {cartTotalCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-[#F26C22] text-white text-[15px] font-bold rounded-full w-7 h-7 flex items-center justify-center shadow-sm animate-pulse">
                {cartTotalCount}
              </span>
            )}
          </button>

          {/* Admin Dashboard shortcut (150% scaled: 18px text, 24px icon) */}
          <button
            onClick={() => navigateTo('admin')}
            title="Admin & CRM Portal"
            className="hidden md:flex p-3 rounded-xl text-[#2C1E16]/60 hover:text-[#2C1E16] hover:bg-[#2C1E16]/5 transition-colors text-[18px] items-center gap-2"
          >
            <Shield className="w-6 h-6" />
            <span className="hidden xl:inline text-[18px] font-medium">Admin</span>
          </button>

          {/* Mobile menu hamburger (150% scaled: 36px icon) */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-3 rounded-xl text-[#2C1E16] hover:bg-[#2C1E16]/5 transition-colors focus:outline-none"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-9 h-9" /> : <Menu className="w-9 h-9" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer (150% scaled navigation items and actions) */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#FAFAFA] border-b border-[#2C1E16]/10 px-4 pt-2 pb-6 space-y-2 shadow-lg animate-in slide-in-from-top duration-200">
          <div className="grid grid-cols-1 gap-1.5">
            {navLinks.map((link) => (
              <button
                key={link.page}
                onClick={() => {
                  navigateTo(link.page);
                  setMobileMenuOpen(false);
                }}
                className={`text-left px-5 py-4 rounded-xl text-[21px] font-medium transition-colors ${
                  activePage === link.page
                    ? 'bg-[#2C1E16] text-white font-semibold'
                    : 'text-[#2C1E16] hover:bg-[#2C1E16]/5'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          <div className="pt-4 border-t border-[#2C1E16]/10 flex flex-col gap-3">
            <a
              href={`https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(
                'Hello Chef Adaeze! I would like to place an order from your mobile menu.'
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-3 py-4 bg-[#F26C22] text-white rounded-xl text-[21px] font-semibold shadow-sm"
            >
              <MessageCircle className="w-6 h-6" />
              <span>Order on WhatsApp (+234 816 616 1317)</span>
            </a>

            <div className="flex items-center justify-between px-2 pt-2 text-[18px] text-[#2C1E16]/70">
              <span className="flex items-center gap-2">
                <PhoneCall className="w-5 h-5 text-[#F26C22]" />
                0816 616 1317
              </span>
              <button
                onClick={() => {
                  navigateTo('admin');
                  setMobileMenuOpen(false);
                }}
                className="text-[#2C1E16] font-semibold underline underline-offset-2"
              >
                Admin CRM &amp; CMS
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
