import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  Course,
  ContentPost,
  Testimonial,
  SiteSettings,
  CustomCakeBooking,
  Order,
  CartItem,
  BookingStatus,
  OrderStatus,
} from '../types';
import {
  INITIAL_PRODUCTS,
  INITIAL_COURSES,
  INITIAL_POSTS,
  INITIAL_TESTIMONIALS,
  INITIAL_BOOKINGS,
  INITIAL_ORDERS,
  INITIAL_SETTINGS,
} from '../data/initialData';

export type ActivePage = 'home' | 'menu' | 'custom-order' | 'academy' | 'content' | 'about' | 'contact' | 'admin';

interface AppContextType {
  // Navigation
  activePage: ActivePage;
  setActivePage: (page: ActivePage) => void;
  navigateTo: (page: ActivePage, sectionId?: string) => void;

  // Products
  products: Product[];
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  toggleProductAvailability: (id: string) => void;

  // Custom Bookings
  bookings: CustomCakeBooking[];
  addBooking: (booking: Omit<CustomCakeBooking, 'id' | 'bookingNumber' | 'createdAt' | 'status'>) => CustomCakeBooking;
  updateBookingStatus: (id: string, status: BookingStatus) => void;
  updateBookingNotes: (id: string, notes: string) => void;
  deleteBooking: (id: string) => void;

  // Orders
  orders: Order[];
  createOrder: (orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'status'>) => Order;
  updateOrderStatus: (id: string, status: OrderStatus) => void;

  // Courses
  courses: Course[];
  addCourse: (course: Omit<Course, 'id' | 'enrolledCount'>) => void;
  updateCourse: (id: string, updates: Partial<Course>) => void;
  enrollInCourse: (courseId: string) => void;

  // Content Posts
  posts: ContentPost[];
  addPost: (post: Omit<ContentPost, 'id' | 'publishedDate'>) => void;
  updatePost: (id: string, updates: Partial<ContentPost>) => void;
  deletePost: (id: string) => void;

  // Testimonials
  testimonials: Testimonial[];

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, customization?: string) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartTotalCount: number;
  cartSubtotal: number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;

  // Site Settings
  settings: SiteSettings;
  updateSettings: (newSettings: Partial<SiteSettings>) => void;

  // Active Modals / Details
  selectedCourse: Course | null;
  setSelectedCourse: (course: Course | null) => void;
  selectedProduct: Product | null;
  setSelectedProduct: (product: Product | null) => void;
  selectedPost: ContentPost | null;
  setSelectedPost: (post: ContentPost | null) => void;

  // Admin Auth simulation
  isAdminAuthenticated: boolean;
  loginAdmin: (passcode: string) => boolean;
  logoutAdmin: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  PRODUCTS: 'ada_bakes_products_v1',
  BOOKINGS: 'ada_bakes_bookings_v1',
  ORDERS: 'ada_bakes_orders_v1',
  COURSES: 'ada_bakes_courses_v1',
  POSTS: 'ada_bakes_posts_v1',
  SETTINGS: 'ada_bakes_settings_v1',
  CART: 'ada_bakes_cart_v1',
  ADMIN_AUTH: 'ada_bakes_admin_auth_v1',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activePage, setActivePage] = useState<ActivePage>('home');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedPost, setSelectedPost] = useState<ContentPost | null>(null);

  // Initialize from LocalStorage or Fallback
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      if (saved) {
        const parsed: Product[] = JSON.parse(saved);
        return parsed.map((p) => {
          const init = INITIAL_PRODUCTS.find((item) => item.id === p.id);
          if (init) {
            return {
              ...p,
              title: init.title,
              slug: init.slug,
              price: init.price,
              description: init.description,
              imageUrl: init.imageUrl,
              piecesOrServings: init.piecesOrServings,
              badge: init.badge ?? p.badge,
            };
          }
          return p;
        });
      }
      return INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [bookings, setBookings] = useState<CustomCakeBooking[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.BOOKINGS);
      return saved ? JSON.parse(saved) : INITIAL_BOOKINGS;
    } catch {
      return INITIAL_BOOKINGS;
    }
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ORDERS);
      return saved ? JSON.parse(saved) : INITIAL_ORDERS;
    } catch {
      return INITIAL_ORDERS;
    }
  });

  const [courses, setCourses] = useState<Course[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.COURSES);
      return saved ? JSON.parse(saved) : INITIAL_COURSES;
    } catch {
      return INITIAL_COURSES;
    }
  });

  const [posts, setPosts] = useState<ContentPost[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.POSTS);
      if (saved) {
        const parsed: ContentPost[] = JSON.parse(saved);
        return parsed.map((p) => {
          const init = INITIAL_POSTS.find((item) => item.id === p.id);
          if (init) {
            return {
              ...p,
              imageUrl: init.imageUrl,
              title: init.title,
              excerpt: init.excerpt,
            };
          }
          return p;
        });
      }
      return INITIAL_POSTS;
    } catch {
      return INITIAL_POSTS;
    }
  });

  const [settings, setSettings] = useState<SiteSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
    } catch {
      return INITIAL_SETTINGS;
    }
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CART);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.ADMIN_AUTH) === 'true';
    } catch {
      return false;
    }
  });

  // Sync to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    } catch (e) {
      console.error(e);
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));
    } catch (e) {
      console.error(e);
    }
  }, [bookings]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    } catch (e) {
      console.error(e);
    }
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(courses));
    } catch (e) {
      console.error(e);
    }
  }, [courses]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.POSTS, JSON.stringify(posts));
    } catch (e) {
      console.error(e);
    }
  }, [posts]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.error(e);
    }
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
    } catch (e) {
      console.error(e);
    }
  }, [cart]);

  // Navigate helper
  const navigateTo = (page: ActivePage, sectionId?: string) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (sectionId) {
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    }
  };

  // Products Handlers
  const addProduct = (newProduct: Omit<Product, 'id'>) => {
    const id = 'prod-' + Date.now();
    setProducts((prev) => [{ ...newProduct, id }, ...prev]);
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const toggleProductAvailability = (id: string) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isAvailable: !p.isAvailable } : p))
    );
  };

  // Custom Bookings Handlers
  const addBooking = (bookingData: Omit<CustomCakeBooking, 'id' | 'bookingNumber' | 'createdAt' | 'status'>) => {
    const randomSuffix = Math.floor(100 + Math.random() * 900);
    const newBooking: CustomCakeBooking = {
      ...bookingData,
      id: 'bk-' + Date.now(),
      bookingNumber: `ABC-${new Date().getFullYear()}-${randomSuffix}`,
      status: 'new_inquiry',
      createdAt: new Date().toISOString(),
    };
    setBookings((prev) => [newBooking, ...prev]);
    return newBooking;
  };

  const updateBookingStatus = (id: string, status: BookingStatus) => {
    setBookings((prev) =>
      prev.map((b) => (b.id === id ? { ...b, status } : b))
    );
  };

  const updateBookingNotes = (id: string, adminNotes: string) => {
    setBookings((prev) =>
      prev.map((b) => (b.id === id ? { ...b, adminNotes } : b))
    );
  };

  const deleteBooking = (id: string) => {
    setBookings((prev) => prev.filter((b) => b.id !== id));
  };

  // Orders Handlers
  const createOrder = (orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'status'>) => {
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const newOrder: Order = {
      ...orderData,
      id: 'ord-' + Date.now(),
      orderNumber: `ABC-ORD-${randomNum}`,
      status: 'confirmed',
      createdAt: new Date().toISOString(),
    };
    setOrders((prev) => [newOrder, ...prev]);
    clearCart();
    return newOrder;
  };

  const updateOrderStatus = (id: string, status: OrderStatus) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === id ? { ...o, status } : o))
    );
  };

  // Courses Handlers
  const addCourse = (courseData: Omit<Course, 'id' | 'enrolledCount'>) => {
    const newCourse: Course = {
      ...courseData,
      id: 'crs-' + Date.now(),
      enrolledCount: 1,
    };
    setCourses((prev) => [...prev, newCourse]);
  };

  const updateCourse = (id: string, updates: Partial<Course>) => {
    setCourses((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updates } : c))
    );
  };

  const enrollInCourse = (courseId: string) => {
    setCourses((prev) =>
      prev.map((c) => (c.id === courseId ? { ...c, enrolledCount: c.enrolledCount + 1 } : c))
    );
  };

  // Posts Handlers
  const addPost = (postData: Omit<ContentPost, 'id' | 'publishedDate'>) => {
    const newPost: ContentPost = {
      ...postData,
      id: 'post-' + Date.now(),
      publishedDate: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }),
    };
    setPosts((prev) => [newPost, ...prev]);
  };

  const updatePost = (id: string, updates: Partial<ContentPost>) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );
  };

  const deletePost = (id: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== id));
  };

  // Cart Handlers
  const addToCart = (product: Product, quantity = 1, customization?: string) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id && item.customization === customization);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id && item.customization === customization
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity, customization }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartTotalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  // Settings Handler
  const updateSettings = (newSettings: Partial<SiteSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  // Admin Auth (Quick pass: "ada2026" or "admin" or instant unlock)
  const loginAdmin = (passcode: string): boolean => {
    const valid = passcode.trim().toLowerCase() === 'ada2026' || passcode.trim().toLowerCase() === 'admin';
    if (valid) {
      setIsAdminAuthenticated(true);
      localStorage.setItem(STORAGE_KEYS.ADMIN_AUTH, 'true');
      return true;
    }
    return false;
  };

  const logoutAdmin = () => {
    setIsAdminAuthenticated(false);
    localStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
  };

  return (
    <AppContext.Provider
      value={{
        activePage,
        setActivePage,
        navigateTo,
        products,
        addProduct,
        updateProduct,
        deleteProduct,
        toggleProductAvailability,
        bookings,
        addBooking,
        updateBookingStatus,
        updateBookingNotes,
        deleteBooking,
        orders,
        createOrder,
        updateOrderStatus,
        courses,
        addCourse,
        updateCourse,
        enrollInCourse,
        posts,
        addPost,
        updatePost,
        deletePost,
        testimonials: INITIAL_TESTIMONIALS,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartTotalCount,
        cartSubtotal,
        isCartOpen,
        setIsCartOpen,
        settings,
        updateSettings,
        selectedCourse,
        setSelectedCourse,
        selectedProduct,
        setSelectedProduct,
        selectedPost,
        setSelectedPost,
        isAdminAuthenticated,
        loginAdmin,
        logoutAdmin,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
